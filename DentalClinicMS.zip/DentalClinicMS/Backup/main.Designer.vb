﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(main))
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip
        Me.PppppppppToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PatientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DoctorDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DoctorTypeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.DoctorDetailToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.EmployeeDetetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EmployeeDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TreatementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TreatementHeaderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TreatementDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CasepaperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CasepaperDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AllDoctorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DoctorSpacilityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AllPatientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PatientAgewiseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PatientGenderwiseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AllCasepaperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TreatmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TrToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PrescriptionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UtilityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PatientBillToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UtilityToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.CalenderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CalculaterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.PictureBox10 = New System.Windows.Forms.PictureBox
        Me.PictureBox6 = New System.Windows.Forms.PictureBox
        Me.PictureBox8 = New System.Windows.Forms.PictureBox
        Me.PictureBox7 = New System.Windows.Forms.PictureBox
        Me.PictureBox5 = New System.Windows.Forms.PictureBox
        Me.PictureBox4 = New System.Windows.Forms.PictureBox
        Me.PictureBox3 = New System.Windows.Forms.PictureBox
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.PictureBox9 = New System.Windows.Forms.PictureBox
        Me.MenuStrip2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.AutoSize = False
        Me.MenuStrip2.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.MenuStrip2.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip2.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Bold)
        Me.MenuStrip2.GripMargin = New System.Windows.Forms.Padding(2, 0, 0, 2)
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PppppppppToolStripMenuItem, Me.DoctorDetailToolStripMenuItem, Me.EmployeeDetetailToolStripMenuItem, Me.TreatementToolStripMenuItem, Me.CasepaperToolStripMenuItem, Me.ReportToolStripMenuItem, Me.UtilityToolStripMenuItem, Me.UtilityToolStripMenuItem1})
        Me.MenuStrip2.Location = New System.Drawing.Point(316, 67)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(1050, 30)
        Me.MenuStrip2.TabIndex = 2
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'PppppppppToolStripMenuItem
        '
        Me.PppppppppToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PatientToolStripMenuItem})
        Me.PppppppppToolStripMenuItem.Name = "PppppppppToolStripMenuItem"
        Me.PppppppppToolStripMenuItem.Size = New System.Drawing.Size(99, 26)
        Me.PppppppppToolStripMenuItem.Text = "    Patient "
        '
        'PatientToolStripMenuItem
        '
        Me.PatientToolStripMenuItem.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.PatientToolStripMenuItem.Name = "PatientToolStripMenuItem"
        Me.PatientToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.PatientToolStripMenuItem.Text = "Patient Detail"
        '
        'DoctorDetailToolStripMenuItem
        '
        Me.DoctorDetailToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DoctorTypeToolStripMenuItem1, Me.DoctorDetailToolStripMenuItem2})
        Me.DoctorDetailToolStripMenuItem.Name = "DoctorDetailToolStripMenuItem"
        Me.DoctorDetailToolStripMenuItem.Size = New System.Drawing.Size(117, 26)
        Me.DoctorDetailToolStripMenuItem.Text = "        Doctor "
        '
        'DoctorTypeToolStripMenuItem1
        '
        Me.DoctorTypeToolStripMenuItem1.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.DoctorTypeToolStripMenuItem1.Name = "DoctorTypeToolStripMenuItem1"
        Me.DoctorTypeToolStripMenuItem1.Size = New System.Drawing.Size(176, 22)
        Me.DoctorTypeToolStripMenuItem1.Text = "Doctor Type"
        '
        'DoctorDetailToolStripMenuItem2
        '
        Me.DoctorDetailToolStripMenuItem2.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.DoctorDetailToolStripMenuItem2.Name = "DoctorDetailToolStripMenuItem2"
        Me.DoctorDetailToolStripMenuItem2.Size = New System.Drawing.Size(176, 22)
        Me.DoctorDetailToolStripMenuItem2.Text = "Doctor Detail"
        '
        'EmployeeDetetailToolStripMenuItem
        '
        Me.EmployeeDetetailToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EmployeeDetailToolStripMenuItem})
        Me.EmployeeDetetailToolStripMenuItem.Name = "EmployeeDetetailToolStripMenuItem"
        Me.EmployeeDetetailToolStripMenuItem.Size = New System.Drawing.Size(145, 26)
        Me.EmployeeDetetailToolStripMenuItem.Text = "         Employee "
        '
        'EmployeeDetailToolStripMenuItem
        '
        Me.EmployeeDetailToolStripMenuItem.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.EmployeeDetailToolStripMenuItem.Name = "EmployeeDetailToolStripMenuItem"
        Me.EmployeeDetailToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.EmployeeDetailToolStripMenuItem.Text = "Employee Detail"
        '
        'TreatementToolStripMenuItem
        '
        Me.TreatementToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TreatementHeaderToolStripMenuItem, Me.TreatementDetailToolStripMenuItem})
        Me.TreatementToolStripMenuItem.Name = "TreatementToolStripMenuItem"
        Me.TreatementToolStripMenuItem.Size = New System.Drawing.Size(109, 26)
        Me.TreatementToolStripMenuItem.Text = "Treatement"
        '
        'TreatementHeaderToolStripMenuItem
        '
        Me.TreatementHeaderToolStripMenuItem.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.TreatementHeaderToolStripMenuItem.Name = "TreatementHeaderToolStripMenuItem"
        Me.TreatementHeaderToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.TreatementHeaderToolStripMenuItem.Text = "Treatement Header"
        '
        'TreatementDetailToolStripMenuItem
        '
        Me.TreatementDetailToolStripMenuItem.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.TreatementDetailToolStripMenuItem.Name = "TreatementDetailToolStripMenuItem"
        Me.TreatementDetailToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.TreatementDetailToolStripMenuItem.Text = "Treatement Detail"
        '
        'CasepaperToolStripMenuItem
        '
        Me.CasepaperToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CasepaperDetailToolStripMenuItem})
        Me.CasepaperToolStripMenuItem.Name = "CasepaperToolStripMenuItem"
        Me.CasepaperToolStripMenuItem.Size = New System.Drawing.Size(102, 26)
        Me.CasepaperToolStripMenuItem.Text = "Casepaper"
        '
        'CasepaperDetailToolStripMenuItem
        '
        Me.CasepaperDetailToolStripMenuItem.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.CasepaperDetailToolStripMenuItem.Name = "CasepaperDetailToolStripMenuItem"
        Me.CasepaperDetailToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.CasepaperDetailToolStripMenuItem.Text = "Casepaper Header"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AllDoctorToolStripMenuItem, Me.DoctorSpacilityToolStripMenuItem, Me.AllPatientToolStripMenuItem, Me.PatientAgewiseToolStripMenuItem, Me.PatientGenderwiseToolStripMenuItem, Me.AllCasepaperToolStripMenuItem, Me.TreatmentToolStripMenuItem, Me.TrToolStripMenuItem, Me.PrescriptionToolStripMenuItem})
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(93, 26)
        Me.ReportToolStripMenuItem.Text = "    Report"
        '
        'AllDoctorToolStripMenuItem
        '
        Me.AllDoctorToolStripMenuItem.Name = "AllDoctorToolStripMenuItem"
        Me.AllDoctorToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.AllDoctorToolStripMenuItem.Text = "All Doctor"
        '
        'DoctorSpacilityToolStripMenuItem
        '
        Me.DoctorSpacilityToolStripMenuItem.Name = "DoctorSpacilityToolStripMenuItem"
        Me.DoctorSpacilityToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.DoctorSpacilityToolStripMenuItem.Text = "Doctor Spacility"
        '
        'AllPatientToolStripMenuItem
        '
        Me.AllPatientToolStripMenuItem.Name = "AllPatientToolStripMenuItem"
        Me.AllPatientToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.AllPatientToolStripMenuItem.Text = "All Patient "
        '
        'PatientAgewiseToolStripMenuItem
        '
        Me.PatientAgewiseToolStripMenuItem.Name = "PatientAgewiseToolStripMenuItem"
        Me.PatientAgewiseToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.PatientAgewiseToolStripMenuItem.Text = "Patient Agewise"
        '
        'PatientGenderwiseToolStripMenuItem
        '
        Me.PatientGenderwiseToolStripMenuItem.Name = "PatientGenderwiseToolStripMenuItem"
        Me.PatientGenderwiseToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.PatientGenderwiseToolStripMenuItem.Text = "Patient Genderwise"
        '
        'AllCasepaperToolStripMenuItem
        '
        Me.AllCasepaperToolStripMenuItem.Name = "AllCasepaperToolStripMenuItem"
        Me.AllCasepaperToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.AllCasepaperToolStripMenuItem.Text = "Casepaper Datewise"
        '
        'TreatmentToolStripMenuItem
        '
        Me.TreatmentToolStripMenuItem.Name = "TreatmentToolStripMenuItem"
        Me.TreatmentToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.TreatmentToolStripMenuItem.Text = "Treatment And Casepaper"
        '
        'TrToolStripMenuItem
        '
        Me.TrToolStripMenuItem.Name = "TrToolStripMenuItem"
        Me.TrToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.TrToolStripMenuItem.Text = "Bill"
        '
        'PrescriptionToolStripMenuItem
        '
        Me.PrescriptionToolStripMenuItem.Name = "PrescriptionToolStripMenuItem"
        Me.PrescriptionToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.PrescriptionToolStripMenuItem.Text = "Prescription"
        '
        'UtilityToolStripMenuItem
        '
        Me.UtilityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PatientBillToolStripMenuItem})
        Me.UtilityToolStripMenuItem.Name = "UtilityToolStripMenuItem"
        Me.UtilityToolStripMenuItem.Size = New System.Drawing.Size(88, 26)
        Me.UtilityToolStripMenuItem.Text = "         Bill"
        '
        'PatientBillToolStripMenuItem
        '
        Me.PatientBillToolStripMenuItem.Name = "PatientBillToolStripMenuItem"
        Me.PatientBillToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.PatientBillToolStripMenuItem.Text = "Patient Bill"
        '
        'UtilityToolStripMenuItem1
        '
        Me.UtilityToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalenderToolStripMenuItem, Me.NotepadToolStripMenuItem, Me.CalculaterToolStripMenuItem})
        Me.UtilityToolStripMenuItem1.Name = "UtilityToolStripMenuItem1"
        Me.UtilityToolStripMenuItem1.Size = New System.Drawing.Size(129, 26)
        Me.UtilityToolStripMenuItem1.Text = "             Utility"
        '
        'CalenderToolStripMenuItem
        '
        Me.CalenderToolStripMenuItem.Name = "CalenderToolStripMenuItem"
        Me.CalenderToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.CalenderToolStripMenuItem.Text = "calender"
        '
        'NotepadToolStripMenuItem
        '
        Me.NotepadToolStripMenuItem.Name = "NotepadToolStripMenuItem"
        Me.NotepadToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.NotepadToolStripMenuItem.Text = "notepad"
        '
        'CalculaterToolStripMenuItem
        '
        Me.CalculaterToolStripMenuItem.Name = "CalculaterToolStripMenuItem"
        Me.CalculaterToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.CalculaterToolStripMenuItem.Text = "calculater"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Panel1.Controls.Add(Me.PictureBox10)
        Me.Panel1.Controls.Add(Me.PictureBox6)
        Me.Panel1.Controls.Add(Me.PictureBox8)
        Me.Panel1.Controls.Add(Me.PictureBox7)
        Me.Panel1.Controls.Add(Me.PictureBox5)
        Me.Panel1.Controls.Add(Me.PictureBox4)
        Me.Panel1.Controls.Add(Me.PictureBox3)
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(295, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1079, 71)
        Me.Panel1.TabIndex = 3
        '
        'PictureBox10
        '
        Me.PictureBox10.BackgroundImage = Global.DentalClinicMS.My.Resources.Resources._118_5123
        Me.PictureBox10.Image = Global.DentalClinicMS.My.Resources.Resources._118_5122
        Me.PictureBox10.Location = New System.Drawing.Point(732, 6)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(66, 61)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox10.TabIndex = 11
        Me.PictureBox10.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.DentalClinicMS.My.Resources.Resources.utility
        Me.PictureBox6.Location = New System.Drawing.Point(840, 6)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(66, 61)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 6
        Me.PictureBox6.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(959, 6)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(66, 61)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox8.TabIndex = 5
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.DentalClinicMS.My.Resources.Resources.report1
        Me.PictureBox7.Location = New System.Drawing.Point(626, 7)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(66, 61)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 5
        Me.PictureBox7.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.DentalClinicMS.My.Resources.Resources._3985a1c647252a93eb9ea3b66e20992c__1_
        Me.PictureBox5.Location = New System.Drawing.Point(515, 7)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(66, 61)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 4
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.DentalClinicMS.My.Resources.Resources._181_512
        Me.PictureBox4.Location = New System.Drawing.Point(408, 7)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(66, 61)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 3
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.DentalClinicMS.My.Resources.Resources._2521___Hospital_Reception_512__1_
        Me.PictureBox3.Location = New System.Drawing.Point(297, 7)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(77, 61)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.DentalClinicMS.My.Resources.Resources.People_Doctor_Male_icon
        Me.PictureBox2.Location = New System.Drawing.Point(170, 7)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(66, 61)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.DentalClinicMS.My.Resources.Resources._1428136341
        Me.PictureBox1.Location = New System.Drawing.Point(50, 7)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(66, 61)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Panel2.Location = New System.Drawing.Point(2, 97)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1384, 10)
        Me.Panel2.TabIndex = 9
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = Global.DentalClinicMS.My.Resources.Resources.logo1
        Me.PictureBox9.Location = New System.Drawing.Point(2, -3)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(311, 100)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 7
        Me.PictureBox9.TabStop = False
        '
        'main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DentalClinicMS.My.Resources.Resources.images_18
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1284, 724)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.IsMdiContainer = True
        Me.Name = "main"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents PppppppppToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents DoctorDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeDetetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreatementToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CasepaperToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UtilityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PatientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DoctorTypeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DoctorDetailToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreatementHeaderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreatementDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CasepaperDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AllDoctorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DoctorSpacilityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AllPatientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatientAgewiseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatientGenderwiseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AllCasepaperToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreatmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TrToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UtilityToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PatientBillToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalenderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotepadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculaterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrescriptionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
