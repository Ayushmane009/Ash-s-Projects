﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Casepaper
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label12 = New System.Windows.Forms.Label
        Me.tbgrandtotal = New System.Windows.Forms.TextBox
        Me.GroupBox10 = New System.Windows.Forms.GroupBox
        Me.dgvcasepaper = New System.Windows.Forms.DataGridView
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.btnexit = New System.Windows.Forms.Button
        Me.btndelete = New System.Windows.Forms.Button
        Me.btnmodify = New System.Windows.Forms.Button
        Me.btnsave = New System.Windows.Forms.Button
        Me.btnnew = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.DCM = New System.Windows.Forms.Label
        Me.tbcharges = New System.Windows.Forms.TextBox
        Me.Label47 = New System.Windows.Forms.Label
        Me.cmbphase = New System.Windows.Forms.ComboBox
        Me.Label46 = New System.Windows.Forms.Label
        Me.LR = New System.Windows.Forms.GroupBox
        Me.lr8 = New System.Windows.Forms.Label
        Me.lr7 = New System.Windows.Forms.Label
        Me.lr6 = New System.Windows.Forms.Label
        Me.lr2 = New System.Windows.Forms.Label
        Me.lr3 = New System.Windows.Forms.Label
        Me.lr4 = New System.Windows.Forms.Label
        Me.lr5 = New System.Windows.Forms.Label
        Me.lr1 = New System.Windows.Forms.Label
        Me.cblr2 = New System.Windows.Forms.CheckBox
        Me.cblr3 = New System.Windows.Forms.CheckBox
        Me.cblr4 = New System.Windows.Forms.CheckBox
        Me.cblr8 = New System.Windows.Forms.CheckBox
        Me.cblr7 = New System.Windows.Forms.CheckBox
        Me.cblr6 = New System.Windows.Forms.CheckBox
        Me.cblr5 = New System.Windows.Forms.CheckBox
        Me.cblr1 = New System.Windows.Forms.CheckBox
        Me.LL = New System.Windows.Forms.GroupBox
        Me.ll1 = New System.Windows.Forms.Label
        Me.ll2 = New System.Windows.Forms.Label
        Me.ll3 = New System.Windows.Forms.Label
        Me.ll7 = New System.Windows.Forms.Label
        Me.ll6 = New System.Windows.Forms.Label
        Me.ll5 = New System.Windows.Forms.Label
        Me.ll4 = New System.Windows.Forms.Label
        Me.ll8 = New System.Windows.Forms.Label
        Me.cbll7 = New System.Windows.Forms.CheckBox
        Me.cbll6 = New System.Windows.Forms.CheckBox
        Me.cbll5 = New System.Windows.Forms.CheckBox
        Me.cbll1 = New System.Windows.Forms.CheckBox
        Me.cbll2 = New System.Windows.Forms.CheckBox
        Me.cbll3 = New System.Windows.Forms.CheckBox
        Me.cbll4 = New System.Windows.Forms.CheckBox
        Me.cbll8 = New System.Windows.Forms.CheckBox
        Me.UR = New System.Windows.Forms.GroupBox
        Me.ur8 = New System.Windows.Forms.Label
        Me.ur7 = New System.Windows.Forms.Label
        Me.ur6 = New System.Windows.Forms.Label
        Me.ur2 = New System.Windows.Forms.Label
        Me.ur3 = New System.Windows.Forms.Label
        Me.ur4 = New System.Windows.Forms.Label
        Me.ur5 = New System.Windows.Forms.Label
        Me.ur1 = New System.Windows.Forms.Label
        Me.cbur2 = New System.Windows.Forms.CheckBox
        Me.cbur3 = New System.Windows.Forms.CheckBox
        Me.cbur4 = New System.Windows.Forms.CheckBox
        Me.cbur8 = New System.Windows.Forms.CheckBox
        Me.cbur7 = New System.Windows.Forms.CheckBox
        Me.cbur6 = New System.Windows.Forms.CheckBox
        Me.cbur5 = New System.Windows.Forms.CheckBox
        Me.cbur1 = New System.Windows.Forms.CheckBox
        Me.UL = New System.Windows.Forms.GroupBox
        Me.ul1 = New System.Windows.Forms.Label
        Me.ul2 = New System.Windows.Forms.Label
        Me.ul3 = New System.Windows.Forms.Label
        Me.ul7 = New System.Windows.Forms.Label
        Me.ul6 = New System.Windows.Forms.Label
        Me.ul5 = New System.Windows.Forms.Label
        Me.ul4 = New System.Windows.Forms.Label
        Me.ul8 = New System.Windows.Forms.Label
        Me.cbul7 = New System.Windows.Forms.CheckBox
        Me.cbul6 = New System.Windows.Forms.CheckBox
        Me.cbul5 = New System.Windows.Forms.CheckBox
        Me.cbul1 = New System.Windows.Forms.CheckBox
        Me.cbul2 = New System.Windows.Forms.CheckBox
        Me.cbul3 = New System.Windows.Forms.CheckBox
        Me.cbul4 = New System.Windows.Forms.CheckBox
        Me.cbul8 = New System.Windows.Forms.CheckBox
        Me.tbcdid = New System.Windows.Forms.TextBox
        Me.dtptdate = New System.Windows.Forms.DateTimePicker
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.casepaperh = New System.Windows.Forms.GroupBox
        Me.btnsaveheder = New System.Windows.Forms.Button
        Me.cmbdid = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.cmbpid = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.btnrenew = New System.Windows.Forms.Button
        Me.btnaddnew = New System.Windows.Forms.Button
        Me.tbfee = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.cmbtid = New System.Windows.Forms.ComboBox
        Me.dtpd = New System.Windows.Forms.DateTimePicker
        Me.dtpvd = New System.Windows.Forms.DateTimePicker
        Me.tbid = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        CType(Me.dgvcasepaper, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.LR.SuspendLayout()
        Me.LL.SuspendLayout()
        Me.UR.SuspendLayout()
        Me.UL.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.casepaperh.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.tbgrandtotal)
        Me.Panel1.Controls.Add(Me.GroupBox10)
        Me.Panel1.Controls.Add(Me.GroupBox9)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.casepaperh)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1041, 520)
        Me.Panel1.TabIndex = 0
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(674, 414)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(72, 14)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "Grand Total"
        '
        'tbgrandtotal
        '
        Me.tbgrandtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbgrandtotal.Location = New System.Drawing.Point(788, 411)
        Me.tbgrandtotal.Name = "tbgrandtotal"
        Me.tbgrandtotal.Size = New System.Drawing.Size(125, 21)
        Me.tbgrandtotal.TabIndex = 24
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.dgvcasepaper)
        Me.GroupBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.Location = New System.Drawing.Point(660, 206)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(368, 189)
        Me.GroupBox10.TabIndex = 10
        Me.GroupBox10.TabStop = False
        '
        'dgvcasepaper
        '
        Me.dgvcasepaper.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvcasepaper.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvcasepaper.Location = New System.Drawing.Point(3, 17)
        Me.dgvcasepaper.Name = "dgvcasepaper"
        Me.dgvcasepaper.Size = New System.Drawing.Size(362, 169)
        Me.dgvcasepaper.TabIndex = 0
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.btnexit)
        Me.GroupBox9.Controls.Add(Me.btndelete)
        Me.GroupBox9.Controls.Add(Me.btnmodify)
        Me.GroupBox9.Controls.Add(Me.btnsave)
        Me.GroupBox9.Controls.Add(Me.btnnew)
        Me.GroupBox9.Location = New System.Drawing.Point(11, 450)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(1014, 62)
        Me.GroupBox9.TabIndex = 7
        Me.GroupBox9.TabStop = False
        '
        'btnexit
        '
        Me.btnexit.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(799, 16)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 30)
        Me.btnexit.TabIndex = 5
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'btndelete
        '
        Me.btndelete.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(574, 19)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(81, 30)
        Me.btndelete.TabIndex = 3
        Me.btndelete.Text = "Delete"
        Me.btndelete.UseVisualStyleBackColor = True
        '
        'btnmodify
        '
        Me.btnmodify.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmodify.Location = New System.Drawing.Point(373, 16)
        Me.btnmodify.Name = "btnmodify"
        Me.btnmodify.Size = New System.Drawing.Size(79, 30)
        Me.btnmodify.TabIndex = 2
        Me.btnmodify.Text = "Modify"
        Me.btnmodify.UseVisualStyleBackColor = True
        '
        'btnsave
        '
        Me.btnsave.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(197, 16)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(86, 30)
        Me.btnsave.TabIndex = 1
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'btnnew
        '
        Me.btnnew.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnew.Location = New System.Drawing.Point(23, 19)
        Me.btnnew.Name = "btnnew"
        Me.btnnew.Size = New System.Drawing.Size(99, 30)
        Me.btnnew.TabIndex = 0
        Me.btnnew.Text = "Add Treatment"
        Me.btnnew.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DCM)
        Me.GroupBox2.Controls.Add(Me.tbcharges)
        Me.GroupBox2.Controls.Add(Me.Label47)
        Me.GroupBox2.Controls.Add(Me.cmbphase)
        Me.GroupBox2.Controls.Add(Me.Label46)
        Me.GroupBox2.Controls.Add(Me.LR)
        Me.GroupBox2.Controls.Add(Me.LL)
        Me.GroupBox2.Controls.Add(Me.UR)
        Me.GroupBox2.Controls.Add(Me.UL)
        Me.GroupBox2.Controls.Add(Me.tbcdid)
        Me.GroupBox2.Controls.Add(Me.dtptdate)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(14, 206)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(640, 243)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Casepaper Details"
        '
        'DCM
        '
        Me.DCM.AutoSize = True
        Me.DCM.Location = New System.Drawing.Point(23, 88)
        Me.DCM.Name = "DCM"
        Me.DCM.Size = New System.Drawing.Size(47, 15)
        Me.DCM.TabIndex = 30
        Me.DCM.Text = "Tooth "
        '
        'tbcharges
        '
        Me.tbcharges.Location = New System.Drawing.Point(473, 64)
        Me.tbcharges.Name = "tbcharges"
        Me.tbcharges.Size = New System.Drawing.Size(125, 21)
        Me.tbcharges.TabIndex = 29
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(331, 64)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(60, 15)
        Me.Label47.TabIndex = 28
        Me.Label47.Text = "Charges"
        '
        'cmbphase
        '
        Me.cmbphase.FormattingEnabled = True
        Me.cmbphase.Location = New System.Drawing.Point(474, 29)
        Me.cmbphase.Name = "cmbphase"
        Me.cmbphase.Size = New System.Drawing.Size(121, 23)
        Me.cmbphase.TabIndex = 27
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(332, 29)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(47, 15)
        Me.Label46.TabIndex = 26
        Me.Label46.Text = "Phase"
        '
        'LR
        '
        Me.LR.Controls.Add(Me.lr8)
        Me.LR.Controls.Add(Me.lr7)
        Me.LR.Controls.Add(Me.lr6)
        Me.LR.Controls.Add(Me.lr2)
        Me.LR.Controls.Add(Me.lr3)
        Me.LR.Controls.Add(Me.lr4)
        Me.LR.Controls.Add(Me.lr5)
        Me.LR.Controls.Add(Me.lr1)
        Me.LR.Controls.Add(Me.cblr2)
        Me.LR.Controls.Add(Me.cblr3)
        Me.LR.Controls.Add(Me.cblr4)
        Me.LR.Controls.Add(Me.cblr8)
        Me.LR.Controls.Add(Me.cblr7)
        Me.LR.Controls.Add(Me.cblr6)
        Me.LR.Controls.Add(Me.cblr5)
        Me.LR.Controls.Add(Me.cblr1)
        Me.LR.Location = New System.Drawing.Point(352, 173)
        Me.LR.Name = "LR"
        Me.LR.Size = New System.Drawing.Size(260, 60)
        Me.LR.TabIndex = 25
        Me.LR.TabStop = False
        Me.LR.Text = "LR"
        '
        'lr8
        '
        Me.lr8.AutoSize = True
        Me.lr8.Location = New System.Drawing.Point(231, 36)
        Me.lr8.Name = "lr8"
        Me.lr8.Size = New System.Drawing.Size(15, 15)
        Me.lr8.TabIndex = 15
        Me.lr8.Text = "8"
        '
        'lr7
        '
        Me.lr7.AutoSize = True
        Me.lr7.Location = New System.Drawing.Point(201, 36)
        Me.lr7.Name = "lr7"
        Me.lr7.Size = New System.Drawing.Size(15, 15)
        Me.lr7.TabIndex = 14
        Me.lr7.Text = "7"
        '
        'lr6
        '
        Me.lr6.AutoSize = True
        Me.lr6.Location = New System.Drawing.Point(169, 37)
        Me.lr6.Name = "lr6"
        Me.lr6.Size = New System.Drawing.Size(15, 15)
        Me.lr6.TabIndex = 13
        Me.lr6.Text = "6"
        '
        'lr2
        '
        Me.lr2.AutoSize = True
        Me.lr2.Location = New System.Drawing.Point(51, 37)
        Me.lr2.Name = "lr2"
        Me.lr2.Size = New System.Drawing.Size(15, 15)
        Me.lr2.TabIndex = 12
        Me.lr2.Text = "2"
        '
        'lr3
        '
        Me.lr3.AutoSize = True
        Me.lr3.Location = New System.Drawing.Point(84, 37)
        Me.lr3.Name = "lr3"
        Me.lr3.Size = New System.Drawing.Size(15, 15)
        Me.lr3.TabIndex = 11
        Me.lr3.Text = "3"
        '
        'lr4
        '
        Me.lr4.AutoSize = True
        Me.lr4.Location = New System.Drawing.Point(109, 37)
        Me.lr4.Name = "lr4"
        Me.lr4.Size = New System.Drawing.Size(15, 15)
        Me.lr4.TabIndex = 10
        Me.lr4.Text = "4"
        '
        'lr5
        '
        Me.lr5.AutoSize = True
        Me.lr5.Location = New System.Drawing.Point(139, 37)
        Me.lr5.Name = "lr5"
        Me.lr5.Size = New System.Drawing.Size(15, 15)
        Me.lr5.TabIndex = 9
        Me.lr5.Text = "5"
        '
        'lr1
        '
        Me.lr1.AutoSize = True
        Me.lr1.Location = New System.Drawing.Point(24, 37)
        Me.lr1.Name = "lr1"
        Me.lr1.Size = New System.Drawing.Size(15, 15)
        Me.lr1.TabIndex = 8
        Me.lr1.Text = "1"
        '
        'cblr2
        '
        Me.cblr2.AutoSize = True
        Me.cblr2.Location = New System.Drawing.Point(51, 20)
        Me.cblr2.Name = "cblr2"
        Me.cblr2.Size = New System.Drawing.Size(15, 14)
        Me.cblr2.TabIndex = 7
        Me.cblr2.UseVisualStyleBackColor = True
        '
        'cblr3
        '
        Me.cblr3.AutoSize = True
        Me.cblr3.Location = New System.Drawing.Point(82, 20)
        Me.cblr3.Name = "cblr3"
        Me.cblr3.Size = New System.Drawing.Size(15, 14)
        Me.cblr3.TabIndex = 6
        Me.cblr3.UseVisualStyleBackColor = True
        '
        'cblr4
        '
        Me.cblr4.AutoSize = True
        Me.cblr4.Location = New System.Drawing.Point(108, 20)
        Me.cblr4.Name = "cblr4"
        Me.cblr4.Size = New System.Drawing.Size(15, 14)
        Me.cblr4.TabIndex = 5
        Me.cblr4.UseVisualStyleBackColor = True
        '
        'cblr8
        '
        Me.cblr8.AutoSize = True
        Me.cblr8.Location = New System.Drawing.Point(231, 19)
        Me.cblr8.Name = "cblr8"
        Me.cblr8.Size = New System.Drawing.Size(15, 14)
        Me.cblr8.TabIndex = 4
        Me.cblr8.UseVisualStyleBackColor = True
        '
        'cblr7
        '
        Me.cblr7.AutoSize = True
        Me.cblr7.Location = New System.Drawing.Point(200, 19)
        Me.cblr7.Name = "cblr7"
        Me.cblr7.Size = New System.Drawing.Size(15, 14)
        Me.cblr7.TabIndex = 3
        Me.cblr7.UseVisualStyleBackColor = True
        '
        'cblr6
        '
        Me.cblr6.AutoSize = True
        Me.cblr6.Location = New System.Drawing.Point(167, 20)
        Me.cblr6.Name = "cblr6"
        Me.cblr6.Size = New System.Drawing.Size(15, 14)
        Me.cblr6.TabIndex = 2
        Me.cblr6.UseVisualStyleBackColor = True
        '
        'cblr5
        '
        Me.cblr5.AutoSize = True
        Me.cblr5.Location = New System.Drawing.Point(137, 20)
        Me.cblr5.Name = "cblr5"
        Me.cblr5.Size = New System.Drawing.Size(15, 14)
        Me.cblr5.TabIndex = 1
        Me.cblr5.UseVisualStyleBackColor = True
        '
        'cblr1
        '
        Me.cblr1.AutoSize = True
        Me.cblr1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cblr1.Location = New System.Drawing.Point(22, 20)
        Me.cblr1.Name = "cblr1"
        Me.cblr1.Size = New System.Drawing.Size(15, 14)
        Me.cblr1.TabIndex = 0
        Me.cblr1.UseVisualStyleBackColor = True
        '
        'LL
        '
        Me.LL.Controls.Add(Me.ll1)
        Me.LL.Controls.Add(Me.ll2)
        Me.LL.Controls.Add(Me.ll3)
        Me.LL.Controls.Add(Me.ll7)
        Me.LL.Controls.Add(Me.ll6)
        Me.LL.Controls.Add(Me.ll5)
        Me.LL.Controls.Add(Me.ll4)
        Me.LL.Controls.Add(Me.ll8)
        Me.LL.Controls.Add(Me.cbll7)
        Me.LL.Controls.Add(Me.cbll6)
        Me.LL.Controls.Add(Me.cbll5)
        Me.LL.Controls.Add(Me.cbll1)
        Me.LL.Controls.Add(Me.cbll2)
        Me.LL.Controls.Add(Me.cbll3)
        Me.LL.Controls.Add(Me.cbll4)
        Me.LL.Controls.Add(Me.cbll8)
        Me.LL.Location = New System.Drawing.Point(20, 170)
        Me.LL.Name = "LL"
        Me.LL.Size = New System.Drawing.Size(260, 60)
        Me.LL.TabIndex = 24
        Me.LL.TabStop = False
        Me.LL.Text = "LL"
        '
        'll1
        '
        Me.ll1.AutoSize = True
        Me.ll1.Location = New System.Drawing.Point(231, 36)
        Me.ll1.Name = "ll1"
        Me.ll1.Size = New System.Drawing.Size(15, 15)
        Me.ll1.TabIndex = 15
        Me.ll1.Text = "1"
        '
        'll2
        '
        Me.ll2.AutoSize = True
        Me.ll2.Location = New System.Drawing.Point(201, 36)
        Me.ll2.Name = "ll2"
        Me.ll2.Size = New System.Drawing.Size(15, 15)
        Me.ll2.TabIndex = 14
        Me.ll2.Text = "2"
        '
        'll3
        '
        Me.ll3.AutoSize = True
        Me.ll3.Location = New System.Drawing.Point(169, 37)
        Me.ll3.Name = "ll3"
        Me.ll3.Size = New System.Drawing.Size(15, 15)
        Me.ll3.TabIndex = 13
        Me.ll3.Text = "3"
        '
        'll7
        '
        Me.ll7.AutoSize = True
        Me.ll7.Location = New System.Drawing.Point(51, 37)
        Me.ll7.Name = "ll7"
        Me.ll7.Size = New System.Drawing.Size(15, 15)
        Me.ll7.TabIndex = 12
        Me.ll7.Text = "7"
        '
        'll6
        '
        Me.ll6.AutoSize = True
        Me.ll6.Location = New System.Drawing.Point(84, 37)
        Me.ll6.Name = "ll6"
        Me.ll6.Size = New System.Drawing.Size(15, 15)
        Me.ll6.TabIndex = 11
        Me.ll6.Text = "6"
        '
        'll5
        '
        Me.ll5.AutoSize = True
        Me.ll5.Location = New System.Drawing.Point(109, 37)
        Me.ll5.Name = "ll5"
        Me.ll5.Size = New System.Drawing.Size(15, 15)
        Me.ll5.TabIndex = 10
        Me.ll5.Text = "5"
        '
        'll4
        '
        Me.ll4.AutoSize = True
        Me.ll4.Location = New System.Drawing.Point(139, 37)
        Me.ll4.Name = "ll4"
        Me.ll4.Size = New System.Drawing.Size(15, 15)
        Me.ll4.TabIndex = 9
        Me.ll4.Text = "4"
        '
        'll8
        '
        Me.ll8.AutoSize = True
        Me.ll8.Location = New System.Drawing.Point(24, 37)
        Me.ll8.Name = "ll8"
        Me.ll8.Size = New System.Drawing.Size(15, 15)
        Me.ll8.TabIndex = 8
        Me.ll8.Text = "8"
        '
        'cbll7
        '
        Me.cbll7.AutoSize = True
        Me.cbll7.Location = New System.Drawing.Point(51, 20)
        Me.cbll7.Name = "cbll7"
        Me.cbll7.Size = New System.Drawing.Size(15, 14)
        Me.cbll7.TabIndex = 7
        Me.cbll7.UseVisualStyleBackColor = True
        '
        'cbll6
        '
        Me.cbll6.AutoSize = True
        Me.cbll6.Location = New System.Drawing.Point(82, 20)
        Me.cbll6.Name = "cbll6"
        Me.cbll6.Size = New System.Drawing.Size(15, 14)
        Me.cbll6.TabIndex = 6
        Me.cbll6.UseVisualStyleBackColor = True
        '
        'cbll5
        '
        Me.cbll5.AutoSize = True
        Me.cbll5.Location = New System.Drawing.Point(108, 20)
        Me.cbll5.Name = "cbll5"
        Me.cbll5.Size = New System.Drawing.Size(15, 14)
        Me.cbll5.TabIndex = 5
        Me.cbll5.UseVisualStyleBackColor = True
        '
        'cbll1
        '
        Me.cbll1.AutoSize = True
        Me.cbll1.Location = New System.Drawing.Point(231, 19)
        Me.cbll1.Name = "cbll1"
        Me.cbll1.Size = New System.Drawing.Size(15, 14)
        Me.cbll1.TabIndex = 4
        Me.cbll1.UseVisualStyleBackColor = True
        '
        'cbll2
        '
        Me.cbll2.AutoSize = True
        Me.cbll2.Location = New System.Drawing.Point(200, 19)
        Me.cbll2.Name = "cbll2"
        Me.cbll2.Size = New System.Drawing.Size(15, 14)
        Me.cbll2.TabIndex = 3
        Me.cbll2.UseVisualStyleBackColor = True
        '
        'cbll3
        '
        Me.cbll3.AutoSize = True
        Me.cbll3.Location = New System.Drawing.Point(167, 20)
        Me.cbll3.Name = "cbll3"
        Me.cbll3.Size = New System.Drawing.Size(15, 14)
        Me.cbll3.TabIndex = 2
        Me.cbll3.UseVisualStyleBackColor = True
        '
        'cbll4
        '
        Me.cbll4.AutoSize = True
        Me.cbll4.Location = New System.Drawing.Point(137, 20)
        Me.cbll4.Name = "cbll4"
        Me.cbll4.Size = New System.Drawing.Size(15, 14)
        Me.cbll4.TabIndex = 1
        Me.cbll4.UseVisualStyleBackColor = True
        '
        'cbll8
        '
        Me.cbll8.AutoSize = True
        Me.cbll8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbll8.Location = New System.Drawing.Point(22, 20)
        Me.cbll8.Name = "cbll8"
        Me.cbll8.Size = New System.Drawing.Size(15, 14)
        Me.cbll8.TabIndex = 0
        Me.cbll8.UseVisualStyleBackColor = True
        '
        'UR
        '
        Me.UR.Controls.Add(Me.ur8)
        Me.UR.Controls.Add(Me.ur7)
        Me.UR.Controls.Add(Me.ur6)
        Me.UR.Controls.Add(Me.ur2)
        Me.UR.Controls.Add(Me.ur3)
        Me.UR.Controls.Add(Me.ur4)
        Me.UR.Controls.Add(Me.ur5)
        Me.UR.Controls.Add(Me.ur1)
        Me.UR.Controls.Add(Me.cbur2)
        Me.UR.Controls.Add(Me.cbur3)
        Me.UR.Controls.Add(Me.cbur4)
        Me.UR.Controls.Add(Me.cbur8)
        Me.UR.Controls.Add(Me.cbur7)
        Me.UR.Controls.Add(Me.cbur6)
        Me.UR.Controls.Add(Me.cbur5)
        Me.UR.Controls.Add(Me.cbur1)
        Me.UR.Location = New System.Drawing.Point(352, 111)
        Me.UR.Name = "UR"
        Me.UR.Size = New System.Drawing.Size(260, 60)
        Me.UR.TabIndex = 24
        Me.UR.TabStop = False
        Me.UR.Text = "UR"
        '
        'ur8
        '
        Me.ur8.AutoSize = True
        Me.ur8.Location = New System.Drawing.Point(231, 36)
        Me.ur8.Name = "ur8"
        Me.ur8.Size = New System.Drawing.Size(15, 15)
        Me.ur8.TabIndex = 15
        Me.ur8.Text = "8"
        '
        'ur7
        '
        Me.ur7.AutoSize = True
        Me.ur7.Location = New System.Drawing.Point(201, 36)
        Me.ur7.Name = "ur7"
        Me.ur7.Size = New System.Drawing.Size(15, 15)
        Me.ur7.TabIndex = 14
        Me.ur7.Text = "7"
        '
        'ur6
        '
        Me.ur6.AutoSize = True
        Me.ur6.Location = New System.Drawing.Point(169, 37)
        Me.ur6.Name = "ur6"
        Me.ur6.Size = New System.Drawing.Size(15, 15)
        Me.ur6.TabIndex = 13
        Me.ur6.Text = "6"
        '
        'ur2
        '
        Me.ur2.AutoSize = True
        Me.ur2.Location = New System.Drawing.Point(51, 37)
        Me.ur2.Name = "ur2"
        Me.ur2.Size = New System.Drawing.Size(15, 15)
        Me.ur2.TabIndex = 12
        Me.ur2.Text = "2"
        '
        'ur3
        '
        Me.ur3.AutoSize = True
        Me.ur3.Location = New System.Drawing.Point(84, 37)
        Me.ur3.Name = "ur3"
        Me.ur3.Size = New System.Drawing.Size(15, 15)
        Me.ur3.TabIndex = 11
        Me.ur3.Text = "3"
        '
        'ur4
        '
        Me.ur4.AutoSize = True
        Me.ur4.Location = New System.Drawing.Point(109, 37)
        Me.ur4.Name = "ur4"
        Me.ur4.Size = New System.Drawing.Size(15, 15)
        Me.ur4.TabIndex = 10
        Me.ur4.Text = "4"
        '
        'ur5
        '
        Me.ur5.AutoSize = True
        Me.ur5.Location = New System.Drawing.Point(139, 37)
        Me.ur5.Name = "ur5"
        Me.ur5.Size = New System.Drawing.Size(15, 15)
        Me.ur5.TabIndex = 9
        Me.ur5.Text = "5"
        '
        'ur1
        '
        Me.ur1.AutoSize = True
        Me.ur1.Location = New System.Drawing.Point(24, 37)
        Me.ur1.Name = "ur1"
        Me.ur1.Size = New System.Drawing.Size(15, 15)
        Me.ur1.TabIndex = 8
        Me.ur1.Text = "1"
        '
        'cbur2
        '
        Me.cbur2.AutoSize = True
        Me.cbur2.Location = New System.Drawing.Point(51, 20)
        Me.cbur2.Name = "cbur2"
        Me.cbur2.Size = New System.Drawing.Size(15, 14)
        Me.cbur2.TabIndex = 7
        Me.cbur2.UseVisualStyleBackColor = True
        '
        'cbur3
        '
        Me.cbur3.AutoSize = True
        Me.cbur3.Location = New System.Drawing.Point(82, 20)
        Me.cbur3.Name = "cbur3"
        Me.cbur3.Size = New System.Drawing.Size(15, 14)
        Me.cbur3.TabIndex = 6
        Me.cbur3.UseVisualStyleBackColor = True
        '
        'cbur4
        '
        Me.cbur4.AutoSize = True
        Me.cbur4.Location = New System.Drawing.Point(108, 20)
        Me.cbur4.Name = "cbur4"
        Me.cbur4.Size = New System.Drawing.Size(15, 14)
        Me.cbur4.TabIndex = 5
        Me.cbur4.UseVisualStyleBackColor = True
        '
        'cbur8
        '
        Me.cbur8.AutoSize = True
        Me.cbur8.Location = New System.Drawing.Point(231, 19)
        Me.cbur8.Name = "cbur8"
        Me.cbur8.Size = New System.Drawing.Size(15, 14)
        Me.cbur8.TabIndex = 4
        Me.cbur8.UseVisualStyleBackColor = True
        '
        'cbur7
        '
        Me.cbur7.AutoSize = True
        Me.cbur7.Location = New System.Drawing.Point(200, 19)
        Me.cbur7.Name = "cbur7"
        Me.cbur7.Size = New System.Drawing.Size(15, 14)
        Me.cbur7.TabIndex = 3
        Me.cbur7.UseVisualStyleBackColor = True
        '
        'cbur6
        '
        Me.cbur6.AutoSize = True
        Me.cbur6.Location = New System.Drawing.Point(167, 20)
        Me.cbur6.Name = "cbur6"
        Me.cbur6.Size = New System.Drawing.Size(15, 14)
        Me.cbur6.TabIndex = 2
        Me.cbur6.UseVisualStyleBackColor = True
        '
        'cbur5
        '
        Me.cbur5.AutoSize = True
        Me.cbur5.Location = New System.Drawing.Point(137, 20)
        Me.cbur5.Name = "cbur5"
        Me.cbur5.Size = New System.Drawing.Size(15, 14)
        Me.cbur5.TabIndex = 1
        Me.cbur5.UseVisualStyleBackColor = True
        '
        'cbur1
        '
        Me.cbur1.AutoSize = True
        Me.cbur1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbur1.Location = New System.Drawing.Point(22, 20)
        Me.cbur1.Name = "cbur1"
        Me.cbur1.Size = New System.Drawing.Size(15, 14)
        Me.cbur1.TabIndex = 0
        Me.cbur1.UseVisualStyleBackColor = True
        '
        'UL
        '
        Me.UL.Controls.Add(Me.ul1)
        Me.UL.Controls.Add(Me.ul2)
        Me.UL.Controls.Add(Me.ul3)
        Me.UL.Controls.Add(Me.ul7)
        Me.UL.Controls.Add(Me.ul6)
        Me.UL.Controls.Add(Me.ul5)
        Me.UL.Controls.Add(Me.ul4)
        Me.UL.Controls.Add(Me.ul8)
        Me.UL.Controls.Add(Me.cbul7)
        Me.UL.Controls.Add(Me.cbul6)
        Me.UL.Controls.Add(Me.cbul5)
        Me.UL.Controls.Add(Me.cbul1)
        Me.UL.Controls.Add(Me.cbul2)
        Me.UL.Controls.Add(Me.cbul3)
        Me.UL.Controls.Add(Me.cbul4)
        Me.UL.Controls.Add(Me.cbul8)
        Me.UL.Location = New System.Drawing.Point(20, 106)
        Me.UL.Name = "UL"
        Me.UL.Size = New System.Drawing.Size(260, 60)
        Me.UL.TabIndex = 23
        Me.UL.TabStop = False
        Me.UL.Text = "UL"
        '
        'ul1
        '
        Me.ul1.AutoSize = True
        Me.ul1.Location = New System.Drawing.Point(231, 36)
        Me.ul1.Name = "ul1"
        Me.ul1.Size = New System.Drawing.Size(15, 15)
        Me.ul1.TabIndex = 15
        Me.ul1.Text = "1"
        '
        'ul2
        '
        Me.ul2.AutoSize = True
        Me.ul2.Location = New System.Drawing.Point(201, 36)
        Me.ul2.Name = "ul2"
        Me.ul2.Size = New System.Drawing.Size(15, 15)
        Me.ul2.TabIndex = 14
        Me.ul2.Text = "2"
        '
        'ul3
        '
        Me.ul3.AutoSize = True
        Me.ul3.Location = New System.Drawing.Point(169, 37)
        Me.ul3.Name = "ul3"
        Me.ul3.Size = New System.Drawing.Size(15, 15)
        Me.ul3.TabIndex = 13
        Me.ul3.Text = "3"
        '
        'ul7
        '
        Me.ul7.AutoSize = True
        Me.ul7.Location = New System.Drawing.Point(51, 37)
        Me.ul7.Name = "ul7"
        Me.ul7.Size = New System.Drawing.Size(15, 15)
        Me.ul7.TabIndex = 12
        Me.ul7.Text = "7"
        '
        'ul6
        '
        Me.ul6.AutoSize = True
        Me.ul6.Location = New System.Drawing.Point(84, 37)
        Me.ul6.Name = "ul6"
        Me.ul6.Size = New System.Drawing.Size(15, 15)
        Me.ul6.TabIndex = 11
        Me.ul6.Text = "6"
        '
        'ul5
        '
        Me.ul5.AutoSize = True
        Me.ul5.Location = New System.Drawing.Point(109, 37)
        Me.ul5.Name = "ul5"
        Me.ul5.Size = New System.Drawing.Size(15, 15)
        Me.ul5.TabIndex = 10
        Me.ul5.Text = "5"
        '
        'ul4
        '
        Me.ul4.AutoSize = True
        Me.ul4.Location = New System.Drawing.Point(139, 37)
        Me.ul4.Name = "ul4"
        Me.ul4.Size = New System.Drawing.Size(15, 15)
        Me.ul4.TabIndex = 9
        Me.ul4.Text = "4"
        '
        'ul8
        '
        Me.ul8.AutoSize = True
        Me.ul8.Location = New System.Drawing.Point(24, 37)
        Me.ul8.Name = "ul8"
        Me.ul8.Size = New System.Drawing.Size(15, 15)
        Me.ul8.TabIndex = 8
        Me.ul8.Text = "8"
        '
        'cbul7
        '
        Me.cbul7.AutoSize = True
        Me.cbul7.Location = New System.Drawing.Point(51, 20)
        Me.cbul7.Name = "cbul7"
        Me.cbul7.Size = New System.Drawing.Size(15, 14)
        Me.cbul7.TabIndex = 7
        Me.cbul7.UseVisualStyleBackColor = True
        '
        'cbul6
        '
        Me.cbul6.AutoSize = True
        Me.cbul6.Location = New System.Drawing.Point(82, 20)
        Me.cbul6.Name = "cbul6"
        Me.cbul6.Size = New System.Drawing.Size(15, 14)
        Me.cbul6.TabIndex = 6
        Me.cbul6.UseVisualStyleBackColor = True
        '
        'cbul5
        '
        Me.cbul5.AutoSize = True
        Me.cbul5.Location = New System.Drawing.Point(108, 20)
        Me.cbul5.Name = "cbul5"
        Me.cbul5.Size = New System.Drawing.Size(15, 14)
        Me.cbul5.TabIndex = 5
        Me.cbul5.UseVisualStyleBackColor = True
        '
        'cbul1
        '
        Me.cbul1.AutoSize = True
        Me.cbul1.Location = New System.Drawing.Point(231, 19)
        Me.cbul1.Name = "cbul1"
        Me.cbul1.Size = New System.Drawing.Size(15, 14)
        Me.cbul1.TabIndex = 4
        Me.cbul1.UseVisualStyleBackColor = True
        '
        'cbul2
        '
        Me.cbul2.AutoSize = True
        Me.cbul2.Location = New System.Drawing.Point(200, 19)
        Me.cbul2.Name = "cbul2"
        Me.cbul2.Size = New System.Drawing.Size(15, 14)
        Me.cbul2.TabIndex = 3
        Me.cbul2.UseVisualStyleBackColor = True
        '
        'cbul3
        '
        Me.cbul3.AutoSize = True
        Me.cbul3.Location = New System.Drawing.Point(167, 20)
        Me.cbul3.Name = "cbul3"
        Me.cbul3.Size = New System.Drawing.Size(15, 14)
        Me.cbul3.TabIndex = 2
        Me.cbul3.UseVisualStyleBackColor = True
        '
        'cbul4
        '
        Me.cbul4.AutoSize = True
        Me.cbul4.Location = New System.Drawing.Point(137, 20)
        Me.cbul4.Name = "cbul4"
        Me.cbul4.Size = New System.Drawing.Size(15, 14)
        Me.cbul4.TabIndex = 1
        Me.cbul4.UseVisualStyleBackColor = True
        '
        'cbul8
        '
        Me.cbul8.AutoSize = True
        Me.cbul8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbul8.Location = New System.Drawing.Point(22, 20)
        Me.cbul8.Name = "cbul8"
        Me.cbul8.Size = New System.Drawing.Size(15, 14)
        Me.cbul8.TabIndex = 0
        Me.cbul8.UseVisualStyleBackColor = True
        '
        'tbcdid
        '
        Me.tbcdid.Location = New System.Drawing.Point(129, 29)
        Me.tbcdid.Name = "tbcdid"
        Me.tbcdid.Size = New System.Drawing.Size(125, 21)
        Me.tbcdid.TabIndex = 21
        '
        'dtptdate
        '
        Me.dtptdate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtptdate.Location = New System.Drawing.Point(124, 58)
        Me.dtptdate.Name = "dtptdate"
        Me.dtptdate.Size = New System.Drawing.Size(177, 21)
        Me.dtptdate.TabIndex = 4
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(13, 64)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(104, 15)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "Treatment date"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 26)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 15)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Details ID"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Location = New System.Drawing.Point(14, 6)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1011, 33)
        Me.Panel2.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(443, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(220, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Casepaper Information"
        '
        'casepaperh
        '
        Me.casepaperh.Controls.Add(Me.btnsaveheder)
        Me.casepaperh.Controls.Add(Me.cmbdid)
        Me.casepaperh.Controls.Add(Me.Label9)
        Me.casepaperh.Controls.Add(Me.cmbpid)
        Me.casepaperh.Controls.Add(Me.Label5)
        Me.casepaperh.Controls.Add(Me.Label7)
        Me.casepaperh.Controls.Add(Me.btnrenew)
        Me.casepaperh.Controls.Add(Me.btnaddnew)
        Me.casepaperh.Controls.Add(Me.tbfee)
        Me.casepaperh.Controls.Add(Me.Label6)
        Me.casepaperh.Controls.Add(Me.cmbtid)
        Me.casepaperh.Controls.Add(Me.dtpd)
        Me.casepaperh.Controls.Add(Me.dtpvd)
        Me.casepaperh.Controls.Add(Me.tbid)
        Me.casepaperh.Controls.Add(Me.Label10)
        Me.casepaperh.Controls.Add(Me.Label4)
        Me.casepaperh.Controls.Add(Me.Label3)
        Me.casepaperh.Controls.Add(Me.Label2)
        Me.casepaperh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.casepaperh.Location = New System.Drawing.Point(11, 43)
        Me.casepaperh.Name = "casepaperh"
        Me.casepaperh.Size = New System.Drawing.Size(1014, 157)
        Me.casepaperh.TabIndex = 5
        Me.casepaperh.TabStop = False
        Me.casepaperh.Text = "Casepaper Header"
        '
        'btnsaveheder
        '
        Me.btnsaveheder.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsaveheder.Location = New System.Drawing.Point(750, 67)
        Me.btnsaveheder.Name = "btnsaveheder"
        Me.btnsaveheder.Size = New System.Drawing.Size(86, 27)
        Me.btnsaveheder.TabIndex = 2
        Me.btnsaveheder.Text = "Save"
        Me.btnsaveheder.UseVisualStyleBackColor = True
        '
        'cmbdid
        '
        Me.cmbdid.FormattingEnabled = True
        Me.cmbdid.Location = New System.Drawing.Point(503, 67)
        Me.cmbdid.Name = "cmbdid"
        Me.cmbdid.Size = New System.Drawing.Size(121, 23)
        Me.cmbdid.TabIndex = 27
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(403, 75)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(91, 15)
        Me.Label9.TabIndex = 26
        Me.Label9.Text = "Doctor Name"
        '
        'cmbpid
        '
        Me.cmbpid.FormattingEnabled = True
        Me.cmbpid.Location = New System.Drawing.Point(195, 91)
        Me.cmbpid.Name = "cmbpid"
        Me.cmbpid.Size = New System.Drawing.Size(121, 23)
        Me.cmbpid.TabIndex = 25
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(77, 99)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(94, 15)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Patient Name"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(81, 63)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(21, 15)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "ID"
        '
        'btnrenew
        '
        Me.btnrenew.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrenew.Location = New System.Drawing.Point(750, 110)
        Me.btnrenew.Name = "btnrenew"
        Me.btnrenew.Size = New System.Drawing.Size(86, 30)
        Me.btnrenew.TabIndex = 22
        Me.btnrenew.Text = "Renew"
        Me.btnrenew.UseVisualStyleBackColor = True
        '
        'btnaddnew
        '
        Me.btnaddnew.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddnew.Location = New System.Drawing.Point(750, 21)
        Me.btnaddnew.Name = "btnaddnew"
        Me.btnaddnew.Size = New System.Drawing.Size(81, 30)
        Me.btnaddnew.TabIndex = 21
        Me.btnaddnew.Text = "Add New"
        Me.btnaddnew.UseVisualStyleBackColor = True
        '
        'tbfee
        '
        Me.tbfee.Location = New System.Drawing.Point(503, 113)
        Me.tbfee.Name = "tbfee"
        Me.tbfee.Size = New System.Drawing.Size(125, 21)
        Me.tbfee.TabIndex = 20
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(406, 119)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 15)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Fee"
        '
        'cmbtid
        '
        Me.cmbtid.FormattingEnabled = True
        Me.cmbtid.Location = New System.Drawing.Point(197, 125)
        Me.cmbtid.Name = "cmbtid"
        Me.cmbtid.Size = New System.Drawing.Size(121, 23)
        Me.cmbtid.TabIndex = 6
        '
        'dtpd
        '
        Me.dtpd.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpd.Location = New System.Drawing.Point(190, 27)
        Me.dtpd.Name = "dtpd"
        Me.dtpd.Size = New System.Drawing.Size(161, 21)
        Me.dtpd.TabIndex = 17
        '
        'dtpvd
        '
        Me.dtpvd.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpvd.Location = New System.Drawing.Point(503, 29)
        Me.dtpvd.Name = "dtpvd"
        Me.dtpvd.Size = New System.Drawing.Size(163, 21)
        Me.dtpvd.TabIndex = 16
        '
        'tbid
        '
        Me.tbid.Location = New System.Drawing.Point(195, 60)
        Me.tbid.Name = "tbid"
        Me.tbid.Size = New System.Drawing.Size(125, 21)
        Me.tbid.TabIndex = 15
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(77, 128)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(114, 15)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Treatment Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(74, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 15)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Date"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(403, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 15)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Validity Date"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 15)
        Me.Label2.TabIndex = 11
        '
        'Casepaper
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1041, 520)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Casepaper"
        Me.Text = "Casepaper"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        CType(Me.dgvcasepaper, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.LR.ResumeLayout(False)
        Me.LR.PerformLayout()
        Me.LL.ResumeLayout(False)
        Me.LL.PerformLayout()
        Me.UR.ResumeLayout(False)
        Me.UR.PerformLayout()
        Me.UL.ResumeLayout(False)
        Me.UL.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.casepaperh.ResumeLayout(False)
        Me.casepaperh.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents casepaperh As System.Windows.Forms.GroupBox
    Friend WithEvents tbfee As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents dtpd As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpvd As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbid As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cmbpid As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cmbtid As System.Windows.Forms.ComboBox
    Friend WithEvents dtptdate As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents btnmodify As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnnew As System.Windows.Forms.Button
    Friend WithEvents UL As System.Windows.Forms.GroupBox
    Friend WithEvents cbul7 As System.Windows.Forms.CheckBox
    Friend WithEvents cbul6 As System.Windows.Forms.CheckBox
    Friend WithEvents cbul5 As System.Windows.Forms.CheckBox
    Friend WithEvents cbul1 As System.Windows.Forms.CheckBox
    Friend WithEvents cbul2 As System.Windows.Forms.CheckBox
    Friend WithEvents cbul3 As System.Windows.Forms.CheckBox
    Friend WithEvents cbul4 As System.Windows.Forms.CheckBox
    Friend WithEvents cbul8 As System.Windows.Forms.CheckBox
    Friend WithEvents tbcdid As System.Windows.Forms.TextBox
    Friend WithEvents ul8 As System.Windows.Forms.Label
    Friend WithEvents ul1 As System.Windows.Forms.Label
    Friend WithEvents ul2 As System.Windows.Forms.Label
    Friend WithEvents ul3 As System.Windows.Forms.Label
    Friend WithEvents ul7 As System.Windows.Forms.Label
    Friend WithEvents ul6 As System.Windows.Forms.Label
    Friend WithEvents ul5 As System.Windows.Forms.Label
    Friend WithEvents ul4 As System.Windows.Forms.Label
    Friend WithEvents LR As System.Windows.Forms.GroupBox
    Friend WithEvents lr8 As System.Windows.Forms.Label
    Friend WithEvents lr7 As System.Windows.Forms.Label
    Friend WithEvents lr6 As System.Windows.Forms.Label
    Friend WithEvents lr2 As System.Windows.Forms.Label
    Friend WithEvents lr3 As System.Windows.Forms.Label
    Friend WithEvents lr4 As System.Windows.Forms.Label
    Friend WithEvents lr5 As System.Windows.Forms.Label
    Friend WithEvents lr1 As System.Windows.Forms.Label
    Friend WithEvents cblr2 As System.Windows.Forms.CheckBox
    Friend WithEvents cblr3 As System.Windows.Forms.CheckBox
    Friend WithEvents cblr4 As System.Windows.Forms.CheckBox
    Friend WithEvents cblr8 As System.Windows.Forms.CheckBox
    Friend WithEvents cblr7 As System.Windows.Forms.CheckBox
    Friend WithEvents cblr6 As System.Windows.Forms.CheckBox
    Friend WithEvents cblr5 As System.Windows.Forms.CheckBox
    Friend WithEvents cblr1 As System.Windows.Forms.CheckBox
    Friend WithEvents LL As System.Windows.Forms.GroupBox
    Friend WithEvents ll1 As System.Windows.Forms.Label
    Friend WithEvents ll2 As System.Windows.Forms.Label
    Friend WithEvents ll3 As System.Windows.Forms.Label
    Friend WithEvents ll7 As System.Windows.Forms.Label
    Friend WithEvents ll6 As System.Windows.Forms.Label
    Friend WithEvents ll5 As System.Windows.Forms.Label
    Friend WithEvents ll4 As System.Windows.Forms.Label
    Friend WithEvents ll8 As System.Windows.Forms.Label
    Friend WithEvents cbll7 As System.Windows.Forms.CheckBox
    Friend WithEvents cbll6 As System.Windows.Forms.CheckBox
    Friend WithEvents cbll5 As System.Windows.Forms.CheckBox
    Friend WithEvents cbll1 As System.Windows.Forms.CheckBox
    Friend WithEvents cbll2 As System.Windows.Forms.CheckBox
    Friend WithEvents cbll3 As System.Windows.Forms.CheckBox
    Friend WithEvents cbll4 As System.Windows.Forms.CheckBox
    Friend WithEvents cbll8 As System.Windows.Forms.CheckBox
    Friend WithEvents UR As System.Windows.Forms.GroupBox
    Friend WithEvents ur8 As System.Windows.Forms.Label
    Friend WithEvents ur7 As System.Windows.Forms.Label
    Friend WithEvents ur6 As System.Windows.Forms.Label
    Friend WithEvents ur2 As System.Windows.Forms.Label
    Friend WithEvents ur3 As System.Windows.Forms.Label
    Friend WithEvents ur4 As System.Windows.Forms.Label
    Friend WithEvents ur5 As System.Windows.Forms.Label
    Friend WithEvents ur1 As System.Windows.Forms.Label
    Friend WithEvents cbur2 As System.Windows.Forms.CheckBox
    Friend WithEvents cbur3 As System.Windows.Forms.CheckBox
    Friend WithEvents cbur4 As System.Windows.Forms.CheckBox
    Friend WithEvents cbur8 As System.Windows.Forms.CheckBox
    Friend WithEvents cbur7 As System.Windows.Forms.CheckBox
    Friend WithEvents cbur6 As System.Windows.Forms.CheckBox
    Friend WithEvents cbur5 As System.Windows.Forms.CheckBox
    Friend WithEvents cbur1 As System.Windows.Forms.CheckBox
    Friend WithEvents cmbdid As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tbcharges As System.Windows.Forms.TextBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents cmbphase As System.Windows.Forms.ComboBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents DCM As System.Windows.Forms.Label
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents dgvcasepaper As System.Windows.Forms.DataGridView
    Friend WithEvents btnsaveheder As System.Windows.Forms.Button
    Friend WithEvents btnrenew As System.Windows.Forms.Button
    Friend WithEvents btnaddnew As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tbgrandtotal As System.Windows.Forms.TextBox
End Class
