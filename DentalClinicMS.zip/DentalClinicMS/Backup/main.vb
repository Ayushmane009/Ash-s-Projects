﻿Public Class main

    

   

    Private Sub PictureBox8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox8.Click
        Me.Close()
    End Sub

    Private Sub DoctorTypeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatientToolStripMenuItem.Click
        Dim p As New Patientdetails()
        p.Show()
    End Sub

    

    Private Sub DoctorTypeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DoctorTypeToolStripMenuItem1.Click
        Dim d As New Form1()
        d.Show()
    End Sub

    Private Sub DoctorDetailToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DoctorDetailToolStripMenuItem2.Click
        Dim s As New Dcotordetails()
        s.Show()
    End Sub

    Private Sub CasepaperDetailToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CasepaperDetailToolStripMenuItem.Click
        Dim z As New casepaperheader()
        z.Show()
    End Sub

  
    Private Sub EmployeeDetailToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EmployeeDetailToolStripMenuItem.Click
        Dim q As New Employdetails()
        q.Show()
    End Sub

    Private Sub TreatementHeaderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TreatementHeaderToolStripMenuItem.Click
        Dim w As New Treatmentheader()
        w.Show()
    End Sub

    Private Sub TreatementDetailToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TreatementDetailToolStripMenuItem.Click
        Dim u As New Treatmentdetails()
        u.Show()
    End Sub

 
 

    Private Sub AllCasepaperToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllCasepaperToolStripMenuItem.Click
        Dim ct As New CaseReportDate()
        ct.Show()
    End Sub

  

    Private Sub AllDoctorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllDoctorToolStripMenuItem.Click
        Dim all As New All_doctor_report()
        all.Show()
    End Sub

    Private Sub DoctorSpacilityToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DoctorSpacilityToolStripMenuItem.Click
        Dim spacility As New DoctorSpacility()
        spacility.Show()
    End Sub

    Private Sub AllPatientToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllPatientToolStripMenuItem.Click

        Dim ae As New All_PatientReport()
        ae.Show()






    End Sub

 

    Private Sub PatientAgewiseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatientAgewiseToolStripMenuItem.Click
        Dim pa As New PatientAgeReport()
        pa.Show()

    End Sub

    Private Sub PatientGenderwiseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatientGenderwiseToolStripMenuItem.Click
        Dim pg As New PatientReportGender()
        pg.Show()
    End Sub

    Private Sub TreatmentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TreatmentToolStripMenuItem.Click
        Dim tc As New TreatmentRep()
        tc.Show()
    End Sub

    Private Sub TrToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrToolStripMenuItem.Click
        Dim bill As New BillReport()
        bill.Show()
    End Sub

    

   

    Private Sub UtilityToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UtilityToolStripMenuItem.Click

    End Sub
    Private Sub main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PatientBillToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatientBillToolStripMenuItem.Click
        Dim pk As New Bill()
        pk.Show()
    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub PictureBox6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox6.Click

    End Sub

    Private Sub main_Load_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub UtilityToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UtilityToolStripMenuItem1.Click

    End Sub

    Private Sub ReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReportToolStripMenuItem.Click

    End Sub

    Private Sub PrescriptionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrescriptionToolStripMenuItem.Click
        Dim ak As New prescription()
        ak.Show()
    End Sub

    Private Sub NotepadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NotepadToolStripMenuItem.Click
        Shell("Notepad")
    End Sub

    Private Sub CalculaterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CalculaterToolStripMenuItem.Click
        Shell("Calc")
    End Sub

    Private Sub CalenderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CalenderToolStripMenuItem.Click
        Dim cal As New Form3()
        cal.Show()
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub
End Class