﻿Imports System.Data.SqlClient
Imports System.Data

Public Class Class1
    Public Shared cn As SqlConnection
    Public Shared cmd As New SqlCommand
    Public Shared dr As SqlDataReader
    Public Shared dr1 As SqlDataReader
    Public Shared dt As New DataTable
    Public Shared dt1 As New DataTable
    Public Shared dt2 As New DataTable
    Public Shared da As New SqlDataAdapter
    Public Shared dt3 As New DataTable
    Public Shared str As String
    Public Shared str1 As String
    'Public Shared p1 As New SqlParameter

    Public Sub conn()
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\DCM\DentalClinicMS\DCM.mdf;Integrated Security=True;User Instance=True")

    End Sub

End Class
