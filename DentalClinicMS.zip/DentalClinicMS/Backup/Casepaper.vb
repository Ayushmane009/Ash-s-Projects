﻿Public Class Casepaper

   
    Private Sub btnaddnew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnaddnew.Click
        Class1.cn.Open()
        Dim k As Integer
        Class1.cmd.CommandText = "Select max(c_id)from Casepaperheader"
        Class1.cmd.Connection = Class1.cn
        Class1.dr = Class1.cmd.ExecuteReader()
        If (Class1.dr.Read()) Then
            Dim str As String
            str = Class1.dr(0).ToString

            If str = "" Then
                tbid.Text = "1"
            Else
                k = Convert.ToInt32(Class1.dr(0).ToString())
                k = k + 1
                tbid.Text = k.ToString()
            End If
        End If
        Class1.cn.Close()
        Showgrid1()
        'Showgrid()
        'clear()
    End Sub

    Private Sub Casepaper_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnaddnew.Enabled = True
        btnrenew.Enabled = True
        btnnew.Enabled = True
        btnsave.Enabled = True
        btnmodify.Enabled = False
        btndelete.Enabled = False
        'btnsearch.Enabled = True
        dtpd.Enabled = True
        dtpvd.Enabled = False
        btnrenew.Enabled = False

            Dim cn1 As New Class1
        cn1.conn()
        Showgrid1()
        'showfield()
        loadtype()
        loadDoctor()
        loadTreatment()
        ' loadphase()
        'Showgrid()
    End Sub

    Private Sub btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub
    Public Sub loadtype()
        Class1.cn.Open()
        Dim dt2 As New DataTable
        Class1.cmd.CommandText = "Select * from Patientdetails"
        Class1.cmd.Connection = Class1.cn
        dt2.Load(Class1.cmd.ExecuteReader)
        cmbpid.DataSource = dt2
        cmbpid.DisplayMember = "p_name"
        cmbpid.ValueMember = "p_id"
        Class1.cn.Close()
    End Sub

    Private Sub btnnew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnew.Click
        Class1.cn.Open()
        Dim k As Integer
        Class1.cmd.CommandText = "Select max(cpd_id)from Casepaperdetails"
        Class1.cmd.Connection = Class1.cn
        Class1.dr = Class1.cmd.ExecuteReader()
        If (Class1.dr.Read()) Then
            Dim str As String
            str = Class1.dr(0).ToString

            If str = "" Then
                tbcdid.Text = "1"
            Else
                k = Convert.ToInt32(Class1.dr(0).ToString())
                k = k + 1
                tbcdid.Text = k.ToString()
            End If
        End If
        Class1.cn.Close()
        Showgrid1()
        'Showgrid()
        'clear()
        casepaperh.Enabled = False
    End Sub
    Public Sub loadDoctor()
        Class1.cn.Open()
        Dim dt2 As New DataTable
        Class1.cmd.CommandText = "Select * from Doctordetails"
        Class1.cmd.Connection = Class1.cn
        dt2.Load(Class1.cmd.ExecuteReader)
        cmbdid.DataSource = dt2
        cmbdid.DisplayMember = "D_name"
        cmbdid.ValueMember = "D_id"
        Class1.cn.Close()
    End Sub
    Public Sub loadTreatment()
        Class1.cn.Open()
        Dim dt2 As New DataTable
        Class1.cmd.CommandText = "Select * from Treatmentheader"
        Class1.cmd.Connection = Class1.cn
        dt2.Load(Class1.cmd.ExecuteReader)
        cmbtid.DataSource = dt2
        cmbtid.DisplayMember = "T_name"
        cmbtid.ValueMember = "T_id"
        Class1.cn.Close()
    End Sub
    Public Sub loadphase()
        Class1.cn.Close()
        Class1.cn.Open()
        Dim dt2 As New DataTable
        Class1.cmd.CommandText = "SELECT  * FROM Treatmentdetails WHERE T_id in (select T_id from Treatmentheader where T_name ='" & cmbtid.Text & "')"
        Class1.cmd.Connection = Class1.cn
        dt2.Load(Class1.cmd.ExecuteReader)
        cmbphase.DataSource = dt2
        cmbphase.DisplayMember = "phase"
        cmbphase.ValueMember = "Td_id"

        Class1.cn.Close()
    End Sub

    Private Sub cmbphase_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbphase.SelectedIndexChanged
        Class1.cn.Close()
        Class1.cn.Open()
        Dim dt2 As New DataTable
        'Class1.cmd.CommandText = "Select charges from Treatmentdetails where phase='" & cmbphase.Text & "'and T_id=" & cmbtid.SelectedValue & ""
        Class1.cmd.CommandText = "SELECT Treatmentdetails.charges FROM Treatmentdetails INNER JOIN Treatmentheader ON Treatmentdetails.T_id = Treatmentheader.T_id WHERE (Treatmentheader.T_name = '" & cmbtid.Text & "') AND (Treatmentdetails.phase = '" & cmbphase.Text & "')"
        Class1.cmd.Connection = Class1.cn

        Class1.dr = Class1.cmd.ExecuteReader

        Dim p As String
        While Class1.dr.Read
            p = Class1.dr(0).ToString()
            tbcharges.Text = p
        End While
        cmbtid.ValueMember = "T_id"
        Class1.cn.Close()

    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        'DCM.Text = ""

        If (cbul8.Checked) Then
            DCM.Text = DCM.Text + UL.Text + ul8.Text
        End If

        If (cbul7.Checked) Then
            DCM.Text = DCM.Text + UL.Text + ul7.Text
        End If

        If (cbul6.Checked) Then
            DCM.Text = DCM.Text + UL.Text + ul6.Text
        End If
        If (cbul5.Checked) Then
            DCM.Text = DCM.Text + UL.Text + ul5.Text
        End If
        If (cbul4.Checked) Then
            DCM.Text = DCM.Text + UL.Text + ul4.Text
        End If
        If (cbul3.Checked) Then
            DCM.Text = UL.Text + ul3.Text
        End If
        If (cbul2.Checked) Then
            DCM.Text = DCM.Text + UL.Text + ul2.Text
        End If
        If (cbul1.Checked) Then
            DCM.Text = DCM.Text + UL.Text + ul1.Text
        End If

        If (cbur1.Checked) Then
            DCM.Text = DCM.Text + UR.Text + ur1.Text
        End If
        If (cbur2.Checked) Then
            DCM.Text = DCM.Text + UR.Text + ur2.Text
        End If
        If (cbur3.Checked) Then
            DCM.Text = DCM.Text + UR.Text + ur3.Text
        End If
        If (cbur4.Checked) Then
            DCM.Text = DCM.Text + UR.Text + ur4.Text
        End If
        If (cbur5.Checked) Then
            DCM.Text = DCM.Text + UR.Text + ur5.Text
        End If
        If (cbur6.Checked) Then
            DCM.Text = DCM.Text + UR.Text + ur6.Text
        End If
        If (cbur7.Checked) Then
            DCM.Text = DCM.Text + UR.Text + ur7.Text
        End If
        If (cbur8.Checked) Then
            DCM.Text = DCM.Text + UR.Text + ur8.Text
        End If
        If (cbll8.Checked) Then
            DCM.Text = DCM.Text + LL.Text + ll8.Text
        End If
        If (cbll7.Checked) Then
            DCM.Text = DCM.Text + LL.Text + ll7.Text
        End If
        If (cbll6.Checked) Then
            DCM.Text = DCM.Text + LL.Text + ll6.Text
        End If
        If (cbll5.Checked) Then
            DCM.Text = DCM.Text + LL.Text + ll5.Text
        End If
        If (cbll4.Checked) Then
            DCM.Text = DCM.Text + LL.Text + ll4.Text
        End If
        If (cbll3.Checked) Then
            DCM.Text = DCM.Text + LL.Text + ll3.Text
        End If
        If (cbll2.Checked) Then
            DCM.Text = DCM.Text + LL.Text + ll2.Text
        End If
        If (cbll1.Checked) Then
            DCM.Text = DCM.Text + LL.Text + ll1.Text
        End If
        If (cblr1.Checked) Then
            DCM.Text = DCM.Text + LR.Text + lr1.Text
        End If
        If (cblr2.Checked) Then
            DCM.Text = DCM.Text + LR.Text + lr2.Text
        End If
        If (cblr3.Checked) Then
            DCM.Text = DCM.Text + LR.Text + lr3.Text
        End If
        If (cblr4.Checked) Then
            DCM.Text = DCM.Text + LR.Text + lr4.Text
        End If
        If (cblr5.Checked) Then
            DCM.Text = DCM.Text + LR.Text + lr5.Text
        End If
        If (cblr6.Checked) Then
            DCM.Text = DCM.Text + LR.Text + lr6.Text
        End If
        If (cblr7.Checked) Then
            DCM.Text = DCM.Text + LR.Text + lr7.Text
        End If
        If (cblr8.Checked) Then
            DCM.Text = DCM.Text + LR.Text + lr8.Text
        End If
        Class1.cn.Open()
        Class1.cmd.CommandText = "insert into Casepaperdetails values (" & tbcdid.Text & "," & tbid.Text & "," & cmbphase.SelectedValue & "," & dtptdate.Text & ",'" & DCM.Text & "')"
        Class1.cmd.Connection = Class1.cn
        Class1.cmd.ExecuteNonQuery()
        MessageBox.Show("Record save successfully", "save", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Class1.cn.Close()
        clear()
        Showgrid1()

        'Showgrid()
    End Sub
    Public Sub clear()
        cbul8.Checked = False
        cbul7.Checked = False
        cbul6.Checked = False
        cbul5.Checked = False
        cbul4.Checked = False
        cbul3.Checked = False
        cbul2.Checked = False
        cbul1.Checked = False

        cbur1.Checked = False
        cbur2.Checked = False
        cbur3.Checked = False
        cbur4.Checked = False
        cbur5.Checked = False
        cbur6.Checked = False
        cbur7.Checked = False
        cbur8.Checked = False

        cbll8.Checked = False
        cbll7.Checked = False
        cbll6.Checked = False
        cbll5.Checked = False
        cbll4.Checked = False
        cbll3.Checked = False
        cbll2.Checked = False
        cbll1.Checked = False


        cblr1.Checked = False
        cblr2.Checked = False
        cblr3.Checked = False
        cblr4.Checked = False
        cblr5.Checked = False
        cblr6.Checked = False
        cblr7.Checked = False
        cblr8.Checked = False
    End Sub


    Private Sub btnsaveheder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsaveheder.Click
        Class1.cn.Open()
        Class1.cmd.CommandText = "insert into Casepaperheader values (" & tbid.Text & "," & dtpd.Text & "," & dtpvd.Text & "," & cmbdid.SelectedValue & "," & cmbpid.SelectedValue & "," & cmbtid.SelectedValue & ",'" & tbfee.Text & "')"
        Class1.cmd.Connection = Class1.cn
        Class1.cmd.ExecuteNonQuery()
        MessageBox.Show("Record save successfully", "save", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Class1.cn.Close()
        'Showgrid()
        Showgrid1()
        

    End Sub
    'Public Sub Showgrid1()
    '    Class1.cn.Open()
    '    Class1.dt1.Clear()
    '    Class1.cmd.CommandText = "Select cpd_id,Td_id,Treat_date,Tooth,c_id,c_date,c_validitydate,D_id,p_id,T_id,c_fee from Casepaperdetails,Casepaperheader"
    '    Class1.cmd.Connection = Class1.cn
    '    Class1.dt1.Load(Class1.cmd.ExecuteReader)
    '    dgvcasepaper.DataSource = Class1.dt1
    '    Class1.cn.Close()
    'End Sub

    'Private Sub dgvcasepaper_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvcasepaper.CellContentClick

    'End Sub
    'Public Sub Showgrid()
    '    Class1.cn.Open()
    '    Class1.dt1.Clear()
    '    Dim dt2 As New DataTable
    '    Class1.cmd.CommandText = "Select * from Casepaperheader"
    '    Class1.cmd.Connection = Class1.cn
    '    dt2.Load(Class1.cmd.ExecuteReader)
    '    dgvcasepaper.DataSource = dt2
    '    Class1.cn.Close()
    'End Sub
    Public Sub Showgrid1()
        Class1.cn.Close()
        Class1.cn.Open()
        Class1.dt1.Clear()
        ' Class1.cmd.CommandText = "SELECT Casepaperdetails.cpd_id, Casepaperdetails.Treat_date, Casepaperdetails.c_id, Treatmentdetails.charges FROM Casepaperdetails INNER JOIN Casepaperheader ON Casepaperdetails.c_id = Casepaperheader.c_id INNER JOIN Treatmentdetails ON Casepaperdetails.Td_id = Treatmentdetails.Td_id INNER JOIN Patientdetails ON Casepaperheader.p_id = Patientdetails.p_id WHERE Patientdetails.p_name = '" & cmbpid.Text & "'"
        Class1.cmd.CommandText = "SELECT Patientdetails.p_name,Treatmentheader.T_name, Treatmentdetails.phase,Casepaperdetails.Tooth,Treat_date,Treatmentdetails.charges FROM Casepaperdetails INNER JOIN Casepaperheader ON Casepaperdetails.c_id = Casepaperheader.c_id INNER JOIN Patientdetails ON Casepaperheader.p_id = Patientdetails.p_id INNER JOIN Treatmentdetails ON Casepaperdetails.Td_id = Treatmentdetails.Td_id INNER JOIN Treatmentheader ON Casepaperheader.T_id = Treatmentheader.T_id WHERE Patientdetails.p_name = '" & cmbpid.Text & "'"
        Class1.cmd.Connection = Class1.cn
        Class1.dt1.Load(Class1.cmd.ExecuteReader)
        dgvcasepaper.DataSource = Class1.dt1
        Class1.cn.Close()
        Dim tot As String = 0

        For i As Integer = 0 To dgvcasepaper.RowCount - 1
            tot = tot + dgvcasepaper.Rows(i).Cells(5).Value
        Next
        tbgrandtotal.Text = tot
        tbcharges.Focus()
    End Sub

    Private Sub btnrenew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrenew.Click

    End Sub
    Private Sub btnmodify_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnmodify.Click
        'Class1.cn.Open()
        'Class1.cmd.CommandText = "Update Doctordetails set Td_id=" & cmbphase.Text & ",Dtype_id=" & cmbdtypename.SelectedIndex + 1 & ",D_address='" & tbaddress.Text & "',D_email='" & tbemail.Text & "',D_qualification='" & tbquali.Text & "',D_contactNo='" & tbcont.Text & "',D_Spaciality='" & cmbspaciality.Text & "' where D_id=" & tbid.Text & ""
        'Class1.cmd.Connection = Class1.cn
        'Class1.cmd.ExecuteNonQuery()
        'MessageBox.Show("Update Sucessfully....", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
        'Class1.cn.Close()
        'Showgrid()
    End Sub

    
    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Class1.cn.Open()
        Class1.cmd.CommandText = "Delete From casepaperdetails where cpd_id=" & tbcdid.Text & ""
        Class1.cmd.Connection = Class1.cn
        Class1.cmd.ExecuteNonQuery()
        MessageBox.Show("Delete Sucessfully....", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Class1.cn.Close()
        Showgrid1()
        btnnew.Enabled = True
        btnaddnew.Enabled = True


    End Sub

    'Private Sub dgvcasepaper_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvcasepaper.CellContentClick
    '    btnnew.Enabled = True
    '    btnsave.Enabled = True
    '    btnmodify.Enabled = True
    '    btndelete.Enabled = True
    '    btnexit.Enabled = True
    '    ' btnsearch.Enabled = True


    '    tbcdid.Text = dgvcasepaper.Rows(e.RowIndex).Cells(0).Value.ToString
    '    tbid.Text = dgvcasepaper.Rows(e.RowIndex).Cells(1).Value.ToString
    '    Dim b As Integer

    '    Dim bstr As String
    '    b = dgvcasepaper.Rows(e.RowIndex).Cells(2).Value.ToString
    '    Class1.cn.Open()
    '    Class1.cmd.CommandText = "Select  phase from Treatmentdetails where Td_id=" & b & " "
    '    Class1.cmd.Connection = Class1.cn
    '    Class1.dr = Class1.cmd.ExecuteReader
    '    While Class1.dr.Read
    '        bstr = Class1.dr("phase")
    '        cmbphase.Text = bstr
    '    End While
    '    Class1.cn.Close()
    '    dtptdate.Text = dgvcasepaper.Rows(e.RowIndex).Cells(3).Value.ToString

    ' tbcharges.Text = dgvcasepaper.Rows(e.RowIndex).Cells(3).Value.ToString

    'End Sub

    Private Sub dgvcasepaper_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvcasepaper.CellDoubleClick
        btnnew.Enabled = True
        btnsave.Enabled = True
        btnmodify.Enabled = True
        btndelete.Enabled = True
        btnexit.Enabled = True
        ' btnsearch.Enabled = True


        tbcdid.Text = dgvcasepaper.Rows(e.RowIndex).Cells(0).Value.ToString
        tbid.Text = dgvcasepaper.Rows(e.RowIndex).Cells(1).Value.ToString
        Dim b As Integer

        Dim bstr As String
        b = dgvcasepaper.Rows(e.RowIndex).Cells(2).Value.ToString
        Class1.cn.Open()
        Class1.cmd.CommandText = "Select  phase from Treatmentdetails where Td_id=" & b & " "
        Class1.cmd.Connection = Class1.cn
        Class1.dr = Class1.cmd.ExecuteReader
        While Class1.dr.Read
            bstr = Class1.dr("phase")
            cmbphase.Text = bstr
        End While
        Class1.cn.Close()
        dtptdate.Text = dgvcasepaper.Rows(e.RowIndex).Cells(3).Value.ToString
        tbcharges.Text = dgvcasepaper.Rows(e.RowIndex).Cells(4).Value.ToString
    End Sub

    
   
   
    Private Sub cmbpid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbpid.SelectedIndexChanged
        Showgrid1()
    End Sub

    Private Sub dgvcasepaper_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvcasepaper.CellContentClick

    End Sub

    Private Sub cmbtid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbtid.SelectedIndexChanged
        loadphase()
    End Sub

    Private Sub dtpvd_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpvd.ValueChanged
        If dtpvd.Text < DateAndTime.Now Then
            MessageBox.Show("Your Casepaper is Expire")
            btnrenew.Enabled = True

        End If


    End Sub

    Private Sub dtpd_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpd.ValueChanged
        dtpvd.Text = dtpd.Value.AddMonths(3)
    End Sub

    Private Sub casepaperh_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles casepaperh.Enter

    End Sub

    Private Sub tbgrandtotal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbgrandtotal.TextChanged

    End Sub

    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label10.Click

    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub
End Class