﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class All_PatientReport

    Private Sub All_PatientReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cryrpt As New ReportDocument()

        'Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\DCM\DentalClinicMS\DCM.mdf;Integrated Security=True;User Instance=True")
        Dim cn1 As New Class1
        cn1.conn()
        ' Showgrid1()

        Dim da As New SqlDataAdapter("select * from Patientdetails ", Class1.cn)
        Dim ds As New DataSet()
        da.Fill(ds, "Patientdetails")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\Allpatient report.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt
    End Sub

End Class