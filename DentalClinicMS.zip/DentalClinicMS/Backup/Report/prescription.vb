﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class prescription
    Dim cryrpt As New ReportDocument()
    Private Sub prescription_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cn1 As New Class1
        cn1.conn()

    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If cmbselecto.Text = "LIKE" Or cmbselecto.Text = "NOT LIKE" Then
                Class1.str = String.Format("{0} where {1}{2}'{3}%'", "Select * from prescriptionview", cmbselectf.Text, cmbselecto.Text, tbsearch.Text)
            ElseIf cmbselecto.Text = "prescriptionview" Then
                Class1.str = String.Format("{0}", "Select * from prescriptionview ", cmbselectf.Text, cmbselecto.Text, tbsearch.Text)
            Else
                Class1.str = String.Format("{0} where {1}{2}'{3}'", "Select * from prescriptionview", cmbselectf.Text, cmbselecto.Text, tbsearch.Text)

            End If
            Class1.cn.Close()
            Class1.cn.Open()

            Dim da As New SqlDataAdapter(Class1.str, Class1.cn)
            Dim ds As New DataSet()
            da.Fill(ds, "prescriptionview")


            cryrpt.Load("D:\DCM\DentalClinicMS\Report\prescriptionrep.rpt")
            cryrpt.SetDataSource(ds)
            CrystalReportViewer1.ReportSource = cryrpt

            Class1.dt.Clear()
            Class1.cmd.CommandText = Class1.str
            Class1.cmd.Connection = Class1.cn
            Class1.dt.Load(Class1.cmd.ExecuteReader)
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            Class1.cn.Close()
            ' dgvPdetails.DataSource = Class1.dt
            tbsearch.Clear()
        End Try
    End Sub

    Private Sub cmbselectf_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbselectf.SelectedIndexChanged

    End Sub
End Class
