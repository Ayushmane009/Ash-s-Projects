﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class BillReport
    Dim cryrpt As New ReportDocument()
    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Public Sub showfield()
        'Try
        '    Class1.cn.Close()
        '    Class1.cn.Open()
        '    Class1.dt.Rows.Clear()
        '    Class1.dt.Columns.Clear()
        '    Class1.cmd.CommandText = "select * from billview"
        '    Class1.cmd.Connection = Class1.cn
        '    Class1.dt.Load(Class1.cmd.ExecuteReader)
        '    Dim dc As DataColumn
        '    For Each dc In Class1.dt.Columns
        '        cmbselectf.Items.Add(dc.ColumnName)

        '    Next
        'Catch ex As Exception
        '    MessageBox.Show(ex.ToString)
        '    Class1.cn.Close()
        'End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\DCM\DentalClinicMS\DCM.mdf;Integrated Security=True;User Instance=True")
        ''Dim a As String = ComboBox1.SelectedValue

        ''Dim da As New SqlDataAdapter("select * from billview where c_id='" & a & "' ", cn)
        ''Dim ds As New DataSet()
        ''da.Fill(ds, "billview")


        ''cryrpt.Load("D:\DCM\DentalClinicMS\Report\billrpt.rpt")
        ''cryrpt.SetDataSource(ds)
        ''CrystalReportViewer1.ReportSource = cryrpt

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BillReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DCMDataSet8.Patientdetails' table. You can move, or remove it, as needed.
        Me.PatientdetailsTableAdapter.Fill(Me.DCMDataSet8.Patientdetails)
        'TODO: This line of code loads data into the 'DCMDataSet7.Casepaperheader' table. You can move, or remove it, as needed.
        Me.CasepaperheaderTableAdapter1.Fill(Me.DCMDataSet7.Casepaperheader)
        'TODO: This line of code loads data into the 'DCMDataSet6.Casepaperheader' table. You can move, or remove it, as needed.
        Me.CasepaperheaderTableAdapter.Fill(Me.DCMDataSet6.Casepaperheader)
        Dim cn1 As New Class1
        cn1.conn()
        showfield()

    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click

        Try
            If cmbselecto.Text = "LIKE" Or cmbselecto.Text = "NOT LIKE" Then
                Class1.str = String.Format("{0} where {1}{2}'{3}%'", "Select * from billview", cmbselectf.Text, cmbselecto.Text, tbsearch.Text)
            ElseIf cmbselecto.Text = "billview" Then
                Class1.str = String.Format("{0}", "Select * from billview ", cmbselectf.Text, cmbselecto.Text, tbsearch.Text)
            Else
                Class1.str = String.Format("{0} where {1}{2}'{3}'", "Select * from billview", cmbselectf.Text, cmbselecto.Text, tbsearch.Text)

            End If
            Class1.cn.Close()
            Class1.cn.Open()

            Dim da As New SqlDataAdapter(Class1.str, Class1.cn)
            Dim ds As New DataSet()
            da.Fill(ds, "billview")


            cryrpt.Load("D:\DCM\DentalClinicMS\Report\billrpt.rpt")
            cryrpt.SetDataSource(ds)
            CrystalReportViewer1.ReportSource = cryrpt

            Class1.dt.Clear()
            Class1.cmd.CommandText = Class1.str
            Class1.cmd.Connection = Class1.cn
            Class1.dt.Load(Class1.cmd.ExecuteReader)
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            Class1.cn.Close()
            ' dgvPdetails.DataSource = Class1.dt
            tbsearch.Clear()
        End Try
    End Sub
End Class