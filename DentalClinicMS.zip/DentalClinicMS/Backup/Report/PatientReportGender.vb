﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class PatientReportGender
    Dim cryrpt As New ReportDocument()

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\DCM\DentalClinicMS\DCM.mdf;Integrated Security=True;User Instance=True")
        Dim a As String = cmbgender.Text

        Dim da As New SqlDataAdapter("select * from Patientdetails where p_Gender='" & a & "' ", cn)
        Dim ds As New DataSet()
        da.Fill(ds, "Patientdetails")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\PatientReportGenderWise.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt
    End Sub

    Private Sub PatientReportGender_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DCMDataSet1.Doctordetails' table. You can move, or remove it, as needed.
        'Me.PatientdetailsTableAdapter.Fill(Me.DCMDataSet1.Patientdetails)
        'TODO: This line of code loads data into the 'DCMDataSet.Doctordetails' table. You can move, or remove it, as needed.
        ' Me.DoctordetailsTableAdapter.Fill(Me.DCMDataSet.Doctordetails)
        'TODO: This line of code loads data into the 'DCMDataSet1.Doctordetails' table. You can move, or remove it, as needed.
        'Me.DoctordetailsTableAdapter.Fill(Me.DCMDataSet1.Doctordetails)
        Dim cn1 As New Class1
        cn1.conn()
        'loadTreatment()
    End Sub
End Class