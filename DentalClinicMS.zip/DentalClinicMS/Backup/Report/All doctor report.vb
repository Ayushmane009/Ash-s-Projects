﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class All_doctor_report
    Dim cryrpt As New ReportDocument()
    Private Sub All_doctor_report_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\DCM\DentalClinicMS\DCM.mdf;Integrated Security=True;User Instance=True")
        Dim cn1 As New Class1
        cn1.conn()
        ' Showgrid1()

        Dim da As New SqlDataAdapter("select * from Doctordetails ", Class1.cn)
        Dim ds As New DataSet()
        da.Fill(ds, "Doctordetails")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\All doctor.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt
    End Sub

    Private Sub CrystalReportViewer1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrystalReportViewer1.Load

    End Sub
End Class