﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Public Class All_Bill
    Dim cryrpt As New ReportDocument()
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\DCM\DentalClinicMS\DCM.mdf;Integrated Security=True;User Instance=True")
        Dim a As String = ComboBox1.SelectedValue

        Dim da As New SqlDataAdapter("select * from  Billtable where c_id='" & a & "' ", cn)
        Dim ds As New DataSet()
        da.Fill(ds, "Billtable")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\billallrpt.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt

    End Sub

    Private Sub CrystalReportViewer1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrystalReportViewer1.Load

    End Sub
End Class