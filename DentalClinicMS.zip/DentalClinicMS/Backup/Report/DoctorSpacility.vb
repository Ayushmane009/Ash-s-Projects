﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class DoctorSpacility
    Dim cryrpt As New ReportDocument()
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click
        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\DCM\DentalClinicMS\DCM.mdf;Integrated Security=True;User Instance=True")
        Dim a As String = ComboBox1.Text

        Dim da As New SqlDataAdapter("select * from Doctordetails where D_Spaciality='" & a & "' ", cn)
        Dim ds As New DataSet()
        da.Fill(ds, "Doctordetails")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\DoctorSpacilityReport.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt

    End Sub

    Private Sub DoctorSpacility_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DCMDataSet1.Doctordetails' table. You can move, or remove it, as needed.
        Me.DoctordetailsTableAdapter.Fill(Me.DCMDataSet1.Doctordetails)
        'TODO: This line of code loads data into the 'DCMDataSet.Doctordetails' table. You can move, or remove it, as needed.
        ' Me.DoctordetailsTableAdapter.Fill(Me.DCMDataSet.Doctordetails)
        'TODO: This line of code loads data into the 'DCMDataSet1.Doctordetails' table. You can move, or remove it, as needed.
        'Me.DoctordetailsTableAdapter.Fill(Me.DCMDataSet1.Doctordetails)
        Dim cn1 As New Class1
        cn1.conn()
        'loadTreatment()
    End Sub


End Class