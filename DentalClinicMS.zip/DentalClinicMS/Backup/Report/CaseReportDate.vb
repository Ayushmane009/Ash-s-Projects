﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Public Class CaseReportDate
    Dim cryrpt As New ReportDocument()
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Dim cn1 As New Class1
            cn1.conn()
            ' Showgrid1()
            Class1.cmd.Parameters.Clear()
            Dim da As New SqlDataAdapter
            Class1.cmd.CommandText = "SELECT  * from patientcase where (c_date between @p1 and @p2)"
            Class1.cmd.Parameters.AddWithValue("@p1", DateTimePicker1.Value)
            Class1.cmd.Parameters.AddWithValue("@p2", DateTimePicker2.Value)
            Class1.cmd.Connection = Class1.cn
            da.SelectCommand = Class1.cmd
            Dim ds As New DataSet()
            da.Fill(ds, "patientcase")


            cryrpt.Load("D:\DCM\DentalClinicMS\Report\casedatewise.rpt")
            cryrpt.SetDataSource(ds)
            CrystalReportViewer1.ReportSource = cryrpt
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally

        End Try
    End Sub

End Class