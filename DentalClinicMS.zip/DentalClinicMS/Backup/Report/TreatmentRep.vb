﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Public Class TreatmentRep
    Dim cryrpt As New ReportDocument()
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndoctor.Click
        Dim cn1 As New Class1
        cn1.conn()
        ' Showgrid1()
        Class1.cmd.Parameters.Clear()
        Dim da As New SqlDataAdapter
        Class1.cmd.CommandText = "SELECT  * from treatmentreportview where D_name='" & ComboBox1.Text & "'"
        'Class1.cmd.Parameters.AddWithValue("@p1", DateTimePicker1.Value)
        'Class1.cmd.Parameters.AddWithValue("@p2", DateTimePicker2.Value)
        Class1.cmd.Connection = Class1.cn
        da.SelectCommand = Class1.cmd
        Dim ds As New DataSet()
        da.Fill(ds, "treatmentreportview")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\TreatmentRepDoctor.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt
    End Sub

    Private Sub TreatmentRep_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DCMDataSet5.Treatmentheader' table. You can move, or remove it, as needed.
        Me.TreatmentheaderTableAdapter.Fill(Me.DCMDataSet5.Treatmentheader)
        'TODO: This line of code loads data into the 'DCMDataSet4.Casepaperheader' table. You can move, or remove it, as needed.
        Me.CasepaperheaderTableAdapter.Fill(Me.DCMDataSet4.Casepaperheader)
        'TODO: This line of code loads data into the 'DCMDataSet3.Doctordetails' table. You can move, or remove it, as needed.
        Me.DoctordetailsTableAdapter1.Fill(Me.DCMDataSet3.Doctordetails)
        'TODO: This line of code loads data into the 'DCMDataSet2.Doctordetails' table. You can move, or remove it, as needed.
        Me.DoctordetailsTableAdapter.Fill(Me.DCMDataSet2.Doctordetails)

    End Sub


    Private Sub btndate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndate.Click
        Dim cn1 As New Class1
        cn1.conn()
        ' Showgrid1()
        Class1.cmd.Parameters.Clear()
        Dim da As New SqlDataAdapter
        Class1.cmd.CommandText = "SELECT  * from treatmentreportview where (c_date between @p1 and @p2) "
        Class1.cmd.Parameters.AddWithValue("@p1", DateTimePicker1.Value)
        Class1.cmd.Parameters.AddWithValue("@p2", DateTimePicker2.Value)
        Class1.cmd.Connection = Class1.cn
        da.SelectCommand = Class1.cmd
        Dim ds As New DataSet()
        da.Fill(ds, "treatmentreportview")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\TreatmentReport.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt
    End Sub

    Private Sub btncasepaper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncasepaper.Click
        Dim cn1 As New Class1
        cn1.conn()
        ' Showgrid1()
        Class1.cmd.Parameters.Clear()
        Dim da As New SqlDataAdapter
        Class1.cmd.CommandText = "SELECT  * from treatmentreportview where c_id='" & ComboBox2.Text & "'"
        'Class1.cmd.Parameters.AddWithValue("@p1", DateTimePicker1.Value)
        'Class1.cmd.Parameters.AddWithValue("@p2", DateTimePicker2.Value)
        Class1.cmd.Connection = Class1.cn
        da.SelectCommand = Class1.cmd
        Dim ds As New DataSet()
        da.Fill(ds, "treatmentreportview")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\TreatmentRepCasepaper.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt
    End Sub

    Private Sub btntreatment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntreatment.Click
        Dim cn1 As New Class1
        cn1.conn()
        ' Showgrid1()
        Class1.cmd.Parameters.Clear()
        Dim da As New SqlDataAdapter
        Class1.cmd.CommandText = "SELECT  * from treatmentreportview where T_name='" & ComboBox3.Text & "'"
        'Class1.cmd.Parameters.AddWithValue("@p1", DateTimePicker1.Value)
        'Class1.cmd.Parameters.AddWithValue("@p2", DateTimePicker2.Value)
        Class1.cmd.Connection = Class1.cn
        da.SelectCommand = Class1.cmd
        Dim ds As New DataSet()
        da.Fill(ds, "treatmentreportview")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\TreatmentRepTreatmentWise.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged

    End Sub

    Private Sub DateTimePicker2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker2.ValueChanged

    End Sub

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker1.ValueChanged

    End Sub
End Class