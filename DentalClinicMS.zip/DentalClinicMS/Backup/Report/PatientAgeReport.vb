﻿Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class PatientAgeReport
    Dim cryrpt As New ReportDocument()
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cn1 As New Class1
        cn1.conn()
        ' Showgrid1()
        Class1.cmd.Parameters.Clear()
        Dim da As New SqlDataAdapter
        Class1.cmd.CommandText = "select * from Patientdetails where (p_DOB between @p1 and @p2)"
        Class1.cmd.Parameters.AddWithValue("@p1", DateTimePicker1.Value)
        Class1.cmd.Parameters.AddWithValue("@p2", DateTimePicker2.Value)
        Class1.cmd.Connection = Class1.cn
        da.SelectCommand = Class1.cmd
        Dim ds As New DataSet()
        da.Fill(ds, "Patientdetails")


        cryrpt.Load("D:\DCM\DentalClinicMS\Report\patientAgeWiseReport.rpt")
        cryrpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = cryrpt
    End Sub
End Class