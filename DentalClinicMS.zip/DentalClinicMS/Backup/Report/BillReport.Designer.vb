﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BillReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.CasepaperheaderBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DCMDataSet6 = New DentalClinicMS.DCMDataSet6
        Me.CasepaperheaderTableAdapter = New DentalClinicMS.DCMDataSet6TableAdapters.CasepaperheaderTableAdapter
        Me.DCMDataSet7 = New DentalClinicMS.DCMDataSet7
        Me.CasepaperheaderBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CasepaperheaderTableAdapter1 = New DentalClinicMS.DCMDataSet7TableAdapters.CasepaperheaderTableAdapter
        Me.DCMDataSet8 = New DentalClinicMS.DCMDataSet8
        Me.PatientdetailsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PatientdetailsTableAdapter = New DentalClinicMS.DCMDataSet8TableAdapters.PatientdetailsTableAdapter
        Me.CrystalReportViewer1 = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.cmbselecto = New System.Windows.Forms.ComboBox
        Me.cmbselectf = New System.Windows.Forms.ComboBox
        Me.tbsearch = New System.Windows.Forms.TextBox
        Me.btnsearch = New System.Windows.Forms.Button
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        CType(Me.CasepaperheaderBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DCMDataSet6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DCMDataSet7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CasepaperheaderBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DCMDataSet8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PatientdetailsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'CasepaperheaderBindingSource
        '
        Me.CasepaperheaderBindingSource.DataMember = "Casepaperheader"
        Me.CasepaperheaderBindingSource.DataSource = Me.DCMDataSet6
        '
        'DCMDataSet6
        '
        Me.DCMDataSet6.DataSetName = "DCMDataSet6"
        Me.DCMDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CasepaperheaderTableAdapter
        '
        Me.CasepaperheaderTableAdapter.ClearBeforeFill = True
        '
        'DCMDataSet7
        '
        Me.DCMDataSet7.DataSetName = "DCMDataSet7"
        Me.DCMDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CasepaperheaderBindingSource1
        '
        Me.CasepaperheaderBindingSource1.DataMember = "Casepaperheader"
        Me.CasepaperheaderBindingSource1.DataSource = Me.DCMDataSet7
        '
        'CasepaperheaderTableAdapter1
        '
        Me.CasepaperheaderTableAdapter1.ClearBeforeFill = True
        '
        'DCMDataSet8
        '
        Me.DCMDataSet8.DataSetName = "DCMDataSet8"
        Me.DCMDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PatientdetailsBindingSource
        '
        Me.PatientdetailsBindingSource.DataMember = "Patientdetails"
        Me.PatientdetailsBindingSource.DataSource = Me.DCMDataSet8
        '
        'PatientdetailsTableAdapter
        '
        Me.PatientdetailsTableAdapter.ClearBeforeFill = True
        '
        'CrystalReportViewer1
        '
        Me.CrystalReportViewer1.ActiveViewIndex = -1
        Me.CrystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CrystalReportViewer1.DisplayGroupTree = False
        Me.CrystalReportViewer1.Location = New System.Drawing.Point(23, 195)
        Me.CrystalReportViewer1.Name = "CrystalReportViewer1"
        Me.CrystalReportViewer1.SelectionFormula = ""
        Me.CrystalReportViewer1.Size = New System.Drawing.Size(713, 242)
        Me.CrystalReportViewer1.TabIndex = 1
        Me.CrystalReportViewer1.ViewTimeSelectionFormula = ""
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(17, 13)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(95, 17)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Select Field"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(258, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(129, 17)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Select Operator"
        '
        'cmbselecto
        '
        Me.cmbselecto.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbselecto.FormattingEnabled = True
        Me.cmbselecto.Items.AddRange(New Object() {"=", "<", ">", "<=", ">=", "LIKE", "NOT LIKE", "MASTER DATA"})
        Me.cmbselecto.Location = New System.Drawing.Point(393, 16)
        Me.cmbselecto.Name = "cmbselecto"
        Me.cmbselecto.Size = New System.Drawing.Size(121, 24)
        Me.cmbselecto.TabIndex = 2
        '
        'cmbselectf
        '
        Me.cmbselectf.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbselectf.FormattingEnabled = True
        Me.cmbselectf.Items.AddRange(New Object() {"c_id", "p_name"})
        Me.cmbselectf.Location = New System.Drawing.Point(131, 13)
        Me.cmbselectf.Name = "cmbselectf"
        Me.cmbselectf.Size = New System.Drawing.Size(121, 24)
        Me.cmbselectf.TabIndex = 3
        '
        'tbsearch
        '
        Me.tbsearch.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbsearch.Location = New System.Drawing.Point(520, 13)
        Me.tbsearch.Name = "tbsearch"
        Me.tbsearch.Size = New System.Drawing.Size(136, 24)
        Me.tbsearch.TabIndex = 4
        '
        'btnsearch
        '
        Me.btnsearch.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.btnsearch.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsearch.Location = New System.Drawing.Point(689, 13)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(79, 28)
        Me.btnsearch.TabIndex = 6
        Me.btnsearch.Text = "Submit"
        Me.btnsearch.UseVisualStyleBackColor = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.btnsearch)
        Me.GroupBox5.Controls.Add(Me.tbsearch)
        Me.GroupBox5.Controls.Add(Me.cmbselectf)
        Me.GroupBox5.Controls.Add(Me.cmbselecto)
        Me.GroupBox5.Controls.Add(Me.Label10)
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Location = New System.Drawing.Point(3, 12)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(774, 47)
        Me.GroupBox5.TabIndex = 7
        Me.GroupBox5.TabStop = False
        '
        'BillReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(778, 449)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.CrystalReportViewer1)
        Me.Name = "BillReport"
        Me.Text = "BillReport"
        CType(Me.CasepaperheaderBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DCMDataSet6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DCMDataSet7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CasepaperheaderBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DCMDataSet8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PatientdetailsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DCMDataSet6 As DentalClinicMS.DCMDataSet6
    Friend WithEvents CasepaperheaderBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CasepaperheaderTableAdapter As DentalClinicMS.DCMDataSet6TableAdapters.CasepaperheaderTableAdapter
    Friend WithEvents DCMDataSet7 As DentalClinicMS.DCMDataSet7
    Friend WithEvents CasepaperheaderBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents CasepaperheaderTableAdapter1 As DentalClinicMS.DCMDataSet7TableAdapters.CasepaperheaderTableAdapter
    Friend WithEvents DCMDataSet8 As DentalClinicMS.DCMDataSet8
    Friend WithEvents PatientdetailsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PatientdetailsTableAdapter As DentalClinicMS.DCMDataSet8TableAdapters.PatientdetailsTableAdapter
    Friend WithEvents CrystalReportViewer1 As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cmbselecto As System.Windows.Forms.ComboBox
    Friend WithEvents cmbselectf As System.Windows.Forms.ComboBox
    Friend WithEvents tbsearch As System.Windows.Forms.TextBox
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
End Class
