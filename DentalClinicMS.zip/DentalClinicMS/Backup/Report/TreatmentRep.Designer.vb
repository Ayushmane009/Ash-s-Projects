﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TreatmentRep
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Tabcontrol1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.btndate = New System.Windows.Forms.Button
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.btndoctor = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.DoctordetailsBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DCMDataSet3 = New DentalClinicMS.DCMDataSet3
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.btncasepaper = New System.Windows.Forms.Button
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.CasepaperheaderBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DCMDataSet4 = New DentalClinicMS.DCMDataSet4
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.btntreatment = New System.Windows.Forms.Button
        Me.ComboBox3 = New System.Windows.Forms.ComboBox
        Me.TreatmentheaderBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DCMDataSet5 = New DentalClinicMS.DCMDataSet5
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.CrystalReportViewer1 = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.DCMDataSet2 = New DentalClinicMS.DCMDataSet2
        Me.DoctordetailsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DoctordetailsTableAdapter = New DentalClinicMS.DCMDataSet2TableAdapters.DoctordetailsTableAdapter
        Me.DoctordetailsTableAdapter1 = New DentalClinicMS.DCMDataSet3TableAdapters.DoctordetailsTableAdapter
        Me.CasepaperheaderTableAdapter = New DentalClinicMS.DCMDataSet4TableAdapters.CasepaperheaderTableAdapter
        Me.TreatmentheaderTableAdapter = New DentalClinicMS.DCMDataSet5TableAdapters.TreatmentheaderTableAdapter
        Me.GroupBox1.SuspendLayout()
        Me.Tabcontrol1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.DoctordetailsBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DCMDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.CasepaperheaderBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DCMDataSet4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.TreatmentheaderBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DCMDataSet5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DCMDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DoctordetailsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Tabcontrol1)
        Me.GroupBox1.Location = New System.Drawing.Point(230, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(410, 230)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Tabcontrol1
        '
        Me.Tabcontrol1.Controls.Add(Me.TabPage1)
        Me.Tabcontrol1.Controls.Add(Me.TabPage2)
        Me.Tabcontrol1.Controls.Add(Me.TabPage3)
        Me.Tabcontrol1.Controls.Add(Me.TabPage4)
        Me.Tabcontrol1.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tabcontrol1.Location = New System.Drawing.Point(6, 11)
        Me.Tabcontrol1.Name = "Tabcontrol1"
        Me.Tabcontrol1.SelectedIndex = 0
        Me.Tabcontrol1.Size = New System.Drawing.Size(398, 205)
        Me.Tabcontrol1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btndate)
        Me.TabPage1.Controls.Add(Me.DateTimePicker2)
        Me.TabPage1.Controls.Add(Me.DateTimePicker1)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(390, 178)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Date"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btndate
        '
        Me.btndate.Location = New System.Drawing.Point(130, 147)
        Me.btndate.Name = "btndate"
        Me.btndate.Size = New System.Drawing.Size(75, 23)
        Me.btndate.TabIndex = 7
        Me.btndate.Text = "Submit"
        Me.btndate.UseVisualStyleBackColor = True
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(106, 104)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(200, 22)
        Me.DateTimePicker2.TabIndex = 6
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(106, 56)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 22)
        Me.DateTimePicker1.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(34, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(21, 14)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "To"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(34, 62)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 14)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "From"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(112, 17)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(174, 14)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "DateWise Report of CasePaper"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.btndoctor)
        Me.TabPage2.Controls.Add(Me.ComboBox1)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Location = New System.Drawing.Point(4, 23)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(390, 178)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Doctor"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'btndoctor
        '
        Me.btndoctor.Location = New System.Drawing.Point(149, 126)
        Me.btndoctor.Name = "btndoctor"
        Me.btndoctor.Size = New System.Drawing.Size(75, 23)
        Me.btndoctor.TabIndex = 7
        Me.btndoctor.Text = "Submit"
        Me.btndoctor.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.DoctordetailsBindingSource1
        Me.ComboBox1.DisplayMember = "D_name"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(122, 82)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 22)
        Me.ComboBox1.TabIndex = 6
        Me.ComboBox1.ValueMember = "D_id"
        '
        'DoctordetailsBindingSource1
        '
        Me.DoctordetailsBindingSource1.DataMember = "Doctordetails"
        Me.DoctordetailsBindingSource1.DataSource = Me.DCMDataSet3
        '
        'DCMDataSet3
        '
        Me.DCMDataSet3.DataSetName = "DCMDataSet3"
        Me.DCMDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(129, 48)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(114, 14)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Select Doctor Name"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(98, 23)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(188, 14)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "DoctorWise Report of CasePaper"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.btncasepaper)
        Me.TabPage3.Controls.Add(Me.ComboBox2)
        Me.TabPage3.Controls.Add(Me.Label9)
        Me.TabPage3.Controls.Add(Me.Label8)
        Me.TabPage3.Location = New System.Drawing.Point(4, 23)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(390, 178)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "CasePaper"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'btncasepaper
        '
        Me.btncasepaper.Location = New System.Drawing.Point(153, 131)
        Me.btncasepaper.Name = "btncasepaper"
        Me.btncasepaper.Size = New System.Drawing.Size(75, 23)
        Me.btncasepaper.TabIndex = 8
        Me.btncasepaper.Text = "Submit"
        Me.btncasepaper.UseVisualStyleBackColor = True
        '
        'ComboBox2
        '
        Me.ComboBox2.DataSource = Me.CasepaperheaderBindingSource
        Me.ComboBox2.DisplayMember = "c_id"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(124, 88)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 22)
        Me.ComboBox2.TabIndex = 7
        Me.ComboBox2.ValueMember = "c_id"
        '
        'CasepaperheaderBindingSource
        '
        Me.CasepaperheaderBindingSource.DataMember = "Casepaperheader"
        Me.CasepaperheaderBindingSource.DataSource = Me.DCMDataSet4
        '
        'DCMDataSet4
        '
        Me.DCMDataSet4.DataSetName = "DCMDataSet4"
        Me.DCMDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(132, 53)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(113, 14)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Select CasePaper Id"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(106, 18)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(174, 14)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "DateWise Report of CasePaper"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.btntreatment)
        Me.TabPage4.Controls.Add(Me.ComboBox3)
        Me.TabPage4.Controls.Add(Me.Label1)
        Me.TabPage4.Controls.Add(Me.Label2)
        Me.TabPage4.Location = New System.Drawing.Point(4, 23)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(390, 178)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Treatment"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'btntreatment
        '
        Me.btntreatment.Location = New System.Drawing.Point(155, 134)
        Me.btntreatment.Name = "btntreatment"
        Me.btntreatment.Size = New System.Drawing.Size(75, 23)
        Me.btntreatment.TabIndex = 12
        Me.btntreatment.Text = "Submit"
        Me.btntreatment.UseVisualStyleBackColor = True
        '
        'ComboBox3
        '
        Me.ComboBox3.DataSource = Me.TreatmentheaderBindingSource
        Me.ComboBox3.DisplayMember = "T_name"
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(126, 91)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 22)
        Me.ComboBox3.TabIndex = 11
        Me.ComboBox3.ValueMember = "T_id"
        '
        'TreatmentheaderBindingSource
        '
        Me.TreatmentheaderBindingSource.DataMember = "Treatmentheader"
        Me.TreatmentheaderBindingSource.DataSource = Me.DCMDataSet5
        '
        'DCMDataSet5
        '
        Me.DCMDataSet5.DataSetName = "DCMDataSet5"
        Me.DCMDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(134, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 14)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Select Treatment Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(108, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(180, 14)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Treatment Report of CasePaper"
        '
        'CrystalReportViewer1
        '
        Me.CrystalReportViewer1.ActiveViewIndex = -1
        Me.CrystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CrystalReportViewer1.DisplayGroupTree = False
        Me.CrystalReportViewer1.Location = New System.Drawing.Point(12, 248)
        Me.CrystalReportViewer1.Name = "CrystalReportViewer1"
        Me.CrystalReportViewer1.SelectionFormula = ""
        Me.CrystalReportViewer1.Size = New System.Drawing.Size(633, 229)
        Me.CrystalReportViewer1.TabIndex = 1
        Me.CrystalReportViewer1.ViewTimeSelectionFormula = ""
        '
        'DCMDataSet2
        '
        Me.DCMDataSet2.DataSetName = "DCMDataSet2"
        Me.DCMDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DoctordetailsBindingSource
        '
        Me.DoctordetailsBindingSource.DataMember = "Doctordetails"
        Me.DoctordetailsBindingSource.DataSource = Me.DCMDataSet2
        '
        'DoctordetailsTableAdapter
        '
        Me.DoctordetailsTableAdapter.ClearBeforeFill = True
        '
        'DoctordetailsTableAdapter1
        '
        Me.DoctordetailsTableAdapter1.ClearBeforeFill = True
        '
        'CasepaperheaderTableAdapter
        '
        Me.CasepaperheaderTableAdapter.ClearBeforeFill = True
        '
        'TreatmentheaderTableAdapter
        '
        Me.TreatmentheaderTableAdapter.ClearBeforeFill = True
        '
        'TreatmentRep
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(657, 489)
        Me.Controls.Add(Me.CrystalReportViewer1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "TreatmentRep"
        Me.Text = "TreatmentReport"
        Me.GroupBox1.ResumeLayout(False)
        Me.Tabcontrol1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DoctordetailsBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DCMDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.CasepaperheaderBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DCMDataSet4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.TreatmentheaderBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DCMDataSet5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DCMDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DoctordetailsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Tabcontrol1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents btndate As System.Windows.Forms.Button
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btndoctor As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btncasepaper As System.Windows.Forms.Button
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btntreatment As System.Windows.Forms.Button
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CrystalReportViewer1 As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents DCMDataSet2 As DentalClinicMS.DCMDataSet2
    Friend WithEvents DoctordetailsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DoctordetailsTableAdapter As DentalClinicMS.DCMDataSet2TableAdapters.DoctordetailsTableAdapter
    Friend WithEvents DCMDataSet3 As DentalClinicMS.DCMDataSet3
    Friend WithEvents DoctordetailsBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents DoctordetailsTableAdapter1 As DentalClinicMS.DCMDataSet3TableAdapters.DoctordetailsTableAdapter
    Friend WithEvents DCMDataSet4 As DentalClinicMS.DCMDataSet4
    Friend WithEvents CasepaperheaderBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CasepaperheaderTableAdapter As DentalClinicMS.DCMDataSet4TableAdapters.CasepaperheaderTableAdapter
    Friend WithEvents DCMDataSet5 As DentalClinicMS.DCMDataSet5
    Friend WithEvents TreatmentheaderBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TreatmentheaderTableAdapter As DentalClinicMS.DCMDataSet5TableAdapters.TreatmentheaderTableAdapter
End Class
