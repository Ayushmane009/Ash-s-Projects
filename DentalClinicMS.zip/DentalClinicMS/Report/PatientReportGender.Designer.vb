﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PatientReportGender
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PatientdetailsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DCMDataSet1 = New DentalClinicMS.DCMDataSet1()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.PatientdetailsTableAdapter = New DentalClinicMS.DCMDataSet1TableAdapters.PatientdetailsTableAdapter()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        CType(Me.PatientdetailsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DCMDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PatientdetailsBindingSource
        '
        Me.PatientdetailsBindingSource.DataMember = "Patientdetails"
        Me.PatientdetailsBindingSource.DataSource = Me.DCMDataSet1
        '
        'DCMDataSet1
        '
        Me.DCMDataSet1.DataSetName = "DCMDataSet1"
        Me.DCMDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnsearch
        '
        Me.btnsearch.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.btnsearch.Location = New System.Drawing.Point(429, 58)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(103, 33)
        Me.btnsearch.TabIndex = 4
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = False
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Male", "Female"})
        Me.ComboBox1.Location = New System.Drawing.Point(286, 58)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 24)
        Me.ComboBox1.TabIndex = 3
        '
        'PatientdetailsTableAdapter
        '
        Me.PatientdetailsTableAdapter.ClearBeforeFill = True
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Location = New System.Drawing.Point(276, 159)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(396, 246)
        Me.ReportViewer1.TabIndex = 5
        '
        'PatientReportGender
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1167, 582)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Controls.Add(Me.btnsearch)
        Me.Controls.Add(Me.ComboBox1)
        Me.Name = "PatientReportGender"
        Me.Text = "PatientReportGender"
        CType(Me.PatientdetailsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DCMDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents PatientdetailsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DCMDataSet1 As DentalClinicMS.DCMDataSet1
    Friend WithEvents PatientdetailsTableAdapter As DentalClinicMS.DCMDataSet1TableAdapters.PatientdetailsTableAdapter
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
End Class
