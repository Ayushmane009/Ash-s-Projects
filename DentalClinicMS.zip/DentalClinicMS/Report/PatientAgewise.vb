﻿Imports System.Windows.Forms
Imports Microsoft.Reporting.WinForms
Imports System.Data.SqlClient

Public Class PatientAgewise
    Dim cn As New SqlConnection
    Private Sub PatientAgewise_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DCMDataSet10.Patientdetails' table. You can move, or remove it, as needed.
        Me.PatientdetailsTableAdapter2.Fill(Me.DCMDataSet10.Patientdetails)
        'TODO: This line of code loads data into the 'DCMDataSet9.prescriptiondetails' table. You can move, or remove it, as needed.
        ' Me.PrescriptiondetailsTableAdapter.Fill(Me.DCMDataSet9.prescriptiondetails)
        'TODO: This line of code loads data into the 'DCMDataSet1.Patientdetails' table. You can move, or remove it, as needed.
        '  Me.PatientdetailsTableAdapter1.Fill(Me.DCMDataSet1.Patientdetails)
        'TODO: This line of code loads data into the 'DCMDataSet8.Patientdetails' table. You can move, or remove it, as needed.
        'Me.PatientdetailsTableAdapter.Fill(Me.DCMDataSet8.Patientdetails)

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Me.PatientdetailsTableAdapter2.Filterbydates(Me.DCMDataSet10.Patientdetails, DateTimePicker1.Value, DateTimePicker2.Value)

        Me.ReportViewer1.RefreshReport()
        'cn.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=D:\DCM\DentalClinicMS\DCM.mdf;Integrated Security=True;User Instance=True"
        'Class1.cmd.Parameters.Clear()
        'Dim da As SqlDataAdapter
        'Class1.cmd.CommandText = "select * from Patientdetails where(p_DOB between @p1 and @p2)"
        'Class1.cmd.Parameters.AddWithValue("@p1", DateTimePicker1.Value)
        'Class1.cmd.Parameters.AddWithValue("@p2", DateTimePicker2.Value)
        'Class1.cmd.Connection = cn
        'Class1.da.Fill(Class1.dt1)
        'ReportViewer1.LocalReport.DataSources.Clear()
        'Dim source As New ReportDataSource("DataSet1", Class1.dt)
        'ReportViewer1.LocalReport.ReportPath = "D:\\DCM\\DentalClinicMS\\Report\\Report4.rdlc"
        'ReportViewer1.LocalReport.DataSources.Add(source)
        'ReportViewer1.RefreshReport()

    End Sub


    Private Function source() As ReportDataSource
        Throw New NotImplementedException
    End Function

End Class