﻿Imports System.Windows.Forms
Imports Microsoft.Reporting.WinForms
Imports System.Data.SqlClient

Public Class PatientReportGender
    Dim cn As New SqlConnection
    Private Sub PatientReportGender_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DCMDataSet1.Patientdetails' table. You can move, or remove it, as needed.
        Me.PatientdetailsTableAdapter.Fill(Me.DCMDataSet1.Patientdetails)

        ' Me.ReportViewer1.RefreshReport()
        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click

        ' Class1.cn.Close()
        ' Class1.cn.Open()
        cn.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=D:\DCM\DentalClinicMS\DCM.mdf;Integrated Security=True;User Instance=True"
        Class1.da = New SqlDataAdapter("Select * from Patientdetails where p_Gender='" & ComboBox1.Text & "'", cn)
        Class1.da.Fill(Class1.dt)
        ReportViewer1.LocalReport.DataSources.Clear()
        Dim source As New ReportDataSource("DataSet1", Class1.dt)
        ReportViewer1.LocalReport.ReportPath = "D:\\DCM\\DentalClinicMS\\Report\\Report4.rdlc"
        ReportViewer1.LocalReport.DataSources.Add(source)
        ReportViewer1.RefreshReport()



    

    End Sub

    Private Function source() As ReportDataSource
        Throw New NotImplementedException
    End Function

End Class